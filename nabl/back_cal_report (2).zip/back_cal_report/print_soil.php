
<style>
	@page {
		margin: 30px 30px;
	}

	.pagebreak {
		page-break-before: always;
	}

	page[size="A4"] {
		width: 29.7cm;
		height: 21cm;
	}
</style>
<style>
	.tdclass {
		border: 1px solid black;
		font-size: 10px;
		font-family: Calibri;
	}

	.test {
		border-collapse: collapse;
		font-size: 13px;
		font-family: Calibri;
	}

	.test1 {
		font-size: 13px;
		border-collapse: collapse;
		font-family: Calibri;

	}

	.tdclass1 {

		font-size: 11px;
		font-family: Calibri;
	}

	.details {
		margin: 0px auto;
		padding: 0px;
	}

	.tr {
		height: 30px;
	}
</style>
<html>

<body>
	


	<page size="A4">



		<br><br>

		<!--harsh-->




		<br>
		<br>
		<page size="A4">


			<!-- WATER CONTENT  -->

			<table align="center" style="width: 95%;text-align: center;border:1px solid;font-family: 'calibri';font-size: 12px" cellspacing="0" cellpadding="2px">
				<tr>
					<td style="width: 20%;text-align: center;font-weight: bold;border-right: 1px solid;" rowspan="6"><img src="../images/mat_logo.png" style="height: 100px;width:120px;background-blend-mode: multiply;"></td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 25px;" colspan="7">DCS ENGINEERS & CONSULTANT Pvt. Ltd.</td>
				</tr>
				<tr>
					<td style="text-align: center;font-size: 15px;" colspan="7">(Formerly known as DC Consulant)</td>
				</tr>
				<tr>
					<td style="text-align: center;font-size: 13px;" colspan="7">Mobile : +91-7018819894, +91-9816755805,e-mail : officialdcspvtltd@gmail.com</td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 14px;" colspan="7">Regd. Office : VPO Taragarh (Rani Di K) Near Taragarh Palace Tehsil Baijnath</td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 14px;" colspan="7">District Kangra Himachal Pradesh (176081)</td>
				</tr>
				<tr>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;border-right: 1px solid;font-size: 20px;">Water Content</td>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;font-size: 20px;" colspan="6"> ANALYSIS DATA SHEET </td>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;font-size: 20px;"> QSF-1001</td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="4"><b>&nbsp;Job Card No:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="4"><b>&nbsp;Test:&nbsp;</b></td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="4"><b>&nbsp;Sample Description:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="4"><b>&nbsp;Method:&nbsp;</b>
					</td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="2"><b>&nbsp;DOR:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left:1px solid;" colspan="2"><b>&nbsp;DOS:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="2"><b>&nbsp;DOC:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left:1px solid;" colspan="2"><b>&nbsp;Page No:&nbsp;</b></td>
				</tr>
				<tr>
					<td style=" text-align: left;border-top: 1px solid;" colspan="3"><b>&nbsp;Sample Qty:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left : 1px solid;" colspan="2"><b> &nbsp;Residual Sample:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left : 1px solid;" colspan="3"><b>&nbsp;Sample Retention:&nbsp;</b></td>
				</tr>
			</table>


			<br>
			<table style="border:1px solid black;width: 95%;text-transform: capitalize;font-family:book antiqua;"align="center" cellspacing="0">
				<tr>
					<td style="border:0px solid;border-bottom:1px solid;font-weight:bold;width:15%;" colspan="4">Determination of Water Content of Soil</td>
				</tr>
			<tr align="left">
				<td style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;width:40%;"><b></b></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;width:20%;"><b>1</b></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;"><b>2 </b></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;border-right:0px;"><b>3 </b></td>
			</tr>
			<tr align="left">
				<td style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;font-Weight:bold;">Weight container with lid (m1)</td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;"></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;"></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;border-right:0px;"></td>
			</tr>
			<tr align="left">
				<td style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;font-Weight:bold;">Weight of container with sample (m2)</td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;0px;"></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;0px;"></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;border-right:0px;"></td>
			</tr>
			<tr align="left">
				<td style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;font-Weight:bold;">Weight of  container with sample after dry</td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;0px;"></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;0px;"></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;border-right:0px;"></td>
			</tr>
			<tr align="left">
				<td style="font-size:18px;border-right:1px solid black;border-top:0px;border-left:0px;font-Weight:bold;">Water content</td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;0px;border-bottom:0px;"></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;0px;border-bottom:0px;"></td>
				<td align="center" style="font-size:18px;border:1px solid black;border-top:0px;border-left:0px;border-right:0px;border-bottom:0px;"></td>
			</tr>
			
		</table>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<table style="width: 95%;" align="center">
				<tr>
					<td style="border: 0;text-align: left;font-size: 15px;font-family: 'calibri'"><b>Checked by</td></b>
					<td style="border: 0;text-align: right;font-size: 15px;font-family: 'calibri'"><b>Analyst</td></b>
				</tr>
			</table>



			<div class="pagebreak"></div>




			<!-- SPECIFIC  GRAVITY OF SOIL -->

			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>


			<table align="center" style="width: 95%;text-align: center;border:1px solid;font-family: 'calibri';font-size: 12px" cellspacing="0" cellpadding="2px">
				<tr>
					<td style="width: 20%;text-align: center;font-weight: bold;border-right: 1px solid;" rowspan="6"><img src="../images/mat_logo.png" style="height: 100px;width:120px;background-blend-mode: multiply;"></td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 25px;" colspan="7">DCS ENGINEERS & CONSULTANT Pvt. Ltd.</td>
				</tr>
				<tr>
					<td style="text-align: center;font-size: 15px;" colspan="7">(Formerly known as DC Consulant)</td>
				</tr>
				<tr>
					<td style="text-align: center;font-size: 13px;" colspan="7">Mobile : +91-7018819894, +91-9816755805,e-mail : officialdcspvtltd@gmail.com</td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 14px;" colspan="7">Regd. Office : VPO Taragarh (Rani Di K) Near Taragarh Palace Tehsil Baijnath</td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 14px;" colspan="7">District Kangra Himachal Pradesh (176081)</td>
				</tr>
				<tr>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;border-right: 1px solid;font-size: 20px;">S.G. of Soil.</td>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;font-size: 20px;" colspan="6"> ANALYSIS DATA SHEET </td>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;font-size: 20px;"> QSF-1001</td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="4"><b>&nbsp;Job Card No:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="4"><b>&nbsp;Test:&nbsp;</b></td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="4"><b>&nbsp;Sample Description:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="4"><b>&nbsp;Method:&nbsp;</b>
					</td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="2"><b>&nbsp;DOR:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left:1px solid;" colspan="2"><b>&nbsp;DOS:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="2"><b>&nbsp;DOC:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left:1px solid;" colspan="2"><b>&nbsp;Page No:&nbsp;</b></td>
				</tr>
				<tr>
					<td style=" text-align: left;border-top: 1px solid;" colspan="3"><b>&nbsp;Sample Qty:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left : 1px solid;" colspan="2"><b> &nbsp;Residual Sample:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left : 1px solid;" colspan="3"><b>&nbsp;Sample Retention:&nbsp;</b></td>
				</tr>
			</table>

			<br>
			<table align="center" style="width: 95%;text-align: center;border:1px solid black;font-family:calibri;border-collapse:collapse;" cellspacing="0" cellpadding="2px">
				<tr>
					<td style="border: 0px solid;font-weight:bold;width:30%;">SPECIFIC GRAVITY FINE SOIL</td>

				</tr>
				<tr>
					<td style="border: 0px solid;font-weight:bold;width:30%;">As Per IS : 2720 PART-3</td>

				</tr>
			</table>
			<br>

			<table align="center" style="width: 95%;text-align: center;border:1px solid black;font-family:calibri;border-collapse:collapse;" cellspacing="0" cellpadding="2px">
				<tr>
					<td style="border: 1px solid;font-weight:bold;width:30%;"></td>
					<td style="border: 1px solid;font-weight:bold;width:20%;"></td>
					<td style="border: 1px solid;font-weight:bold;width:10%;">Unit</td>
					<td style="border: 1px solid;font-weight:bold;width:10%;">1</td>
					<td style="border: 1px solid;font-weight:bold;width:10%;">2</td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align:left;">Wt. of Density Bottle</td>
					<td style="border:1px solid;">W1</td>
					<td style="border:1px solid;">gm</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align:left;">Wt. of Density Bottle + dry soil</td>
					<td style="border:1px solid;">W2</td>
					<td style="border:1px solid;">gm</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align:left;">Wt. of Density Bottle + Soil + Water</td>
					<td style="border:1px solid;">W3</td>
					<td style="border:1px solid;">gm</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align:left;">Wt. of Density Bottle + Water</td>
					<td style="border:1px solid;">W4</td>
					<td style="border:1px solid;">gm</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align:left;">Specfic Gravity</td>
					<td style="border:1px solid;">W2-W1/<br>(W4-W1) - (W3-W2)</td>
					<td style="border:1px solid;">%</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td colspan="2" style="border:1px solid;text-align:left;">Average</td>
					<td style="border:1px solid;">%</td>
					<td colspan="2"style="border:1px solid;"></td>
				</tr>
			</table>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<table style="width: 95%;" align="center">
				<tr>
					<td style="border: 0;text-align: left;font-size: 15px;font-family: 'calibri'"><b>Checked by</td></b>
					<td style="border: 0;text-align: right;font-size: 15px;font-family: 'calibri'"><b>Analyst</td></b>
				</tr>
			</table>



			<div class="pagebreak"></div>


			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>




			<!-- Sieve Analysis -->


			<table align="center" style="width: 95%;text-align: center;border:1px solid;font-family: 'calibri';font-size: 12px" cellspacing="0" cellpadding="2px">
				<tr>
					<td style="width: 20%;text-align: center;font-weight: bold;border-right: 1px solid;" rowspan="6"><img src="../images/mat_logo.png" style="height: 100px;width:120px;background-blend-mode: multiply;"></td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 25px;" colspan="7">DCS ENGINEERS & CONSULTANT Pvt. Ltd.</td>
				</tr>
				<tr>
					<td style="text-align: center;font-size: 15px;" colspan="7">(Formerly known as DC Consulant)</td>
				</tr>
				<tr>
					<td style="text-align: center;font-size: 13px;" colspan="7">Mobile : +91-7018819894, +91-9816755805,e-mail : officialdcspvtltd@gmail.com</td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 14px;" colspan="7">Regd. Office : VPO Taragarh (Rani Di K) Near Taragarh Palace Tehsil Baijnath</td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 14px;" colspan="7">District Kangra Himachal Pradesh (176081)</td>
				</tr>
				<tr>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;border-right: 1px solid;font-size: 20px;">Sieve Analysis</td>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;font-size: 20px;" colspan="6"> ANALYSIS DATA SHEET </td>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;font-size: 20px;"> QSF-1001</td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="4"><b>&nbsp;Job Card No:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="4"><b>&nbsp;Test:&nbsp;</b></td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="4"><b>&nbsp;Sample Description:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="4"><b>&nbsp;Method:&nbsp;</b>
					</td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="2"><b>&nbsp;DOR:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left:1px solid;" colspan="2"><b>&nbsp;DOS:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="2"><b>&nbsp;DOC:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left:1px solid;" colspan="2"><b>&nbsp;Page No:&nbsp;</b></td>
				</tr>
				<tr>
					<td style=" text-align: left;border-top: 1px solid;" colspan="3"><b>&nbsp;Sample Qty:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left : 1px solid;" colspan="2"><b> &nbsp;Residual Sample:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left : 1px solid;" colspan="3"><b>&nbsp;Sample Retention:&nbsp;</b></td>
				</tr>
			</table>


			<br>
			<table align="center" style="width: 95%;text-align: center;border:1px solid black;font-family:calibri;border-collapse:collapse;" cellspacing="0" cellpadding="2px">
				<tr>
					<td style="border: 0px solid;font-weight:bold;width:15%;" colspan="5">GRAIN SIZE ANALYSIS OF SOIL</td>
				</tr>
				<tr>
					<td style="border: 0px solid;font-weight:bold;width:15%;" colspan="5">(As Per IS: 2720 ,Part-4)</td>
				</tr>

				<tr>
					<td style="border:1px solid;width:20%;">IS SIEVE<BR>(mm).</td>
					<td style="border:1px solid;width:20%;">Weight <br>Retained (gms)</td>
					<td style="border:1px solid;width:20%;">Cumulative Wt.<BR> Retained (gms)</td>
					<td style="border:1px solid;width:20%;">Cumulative % <br>Retained </td>
					<td style="border:1px solid;width:20%;">% of Passing</td>

				</tr>
				<tr>
					<td style="border:1px solid;">100 mm</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>

				</tr>
				<tr>
					<td style="border:1px solid;">75 mm</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>

				</tr>
				<tr>
					<td style="border:1px solid;">20 mm</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>

				</tr>

				<tr>
					<td style="border:1px solid;">10 mm</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>

				</tr>

				<tr>
					<td style="border:1px solid;">4.75 mm</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>

				</tr>

				<tr>
					<td style="border:1px solid;">2.0 mm</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>

				</tr>

				<tr>
					<td style="border:1px solid;">425 μ </td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>

				</tr>
				<tr>
					<td style="border:1px solid;">75 μ</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>

				</tr>
				<tr>
					<td style="border: 0px solid;width:15%; text-align: left;" colspan="5">Gravel Content = %</td>
				</tr>
				<tr>
					<td style="border: 0px solid;width:15%; text-align: left;" colspan="5">Sand Content = %</td>
				</tr>
				<tr>
					<td style="border: 0px solid;width:15%; text-align: left;" colspan="5">Sit & Clay Content = %</td>
				</tr>


			</table>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<table style="width: 92%;" align="center">
				<tr>
					<td style="border: 0;text-align: left;font-size: 15px;font-family: 'calibri'"><b>Checked by</td></b>
					<td style="border: 0;text-align: right;font-size: 15px;font-family: 'calibri'"><b>Analyst</td></b>
				</tr>
			</table>



			<div class="pagebreak"></div>



			<br>
			<br>
			<br>
			<br>



			<!-- CBR -->


			<table align="center" style="width: 95%;text-align: center;border:1px solid;font-family: 'calibri';font-size: 12px" cellspacing="0" cellpadding="2px">
				<tr>
					<td style="width: 20%;text-align: center;font-weight: bold;border-right: 1px solid;" rowspan="6"><img src="../images/mat_logo.png" style="height: 100px;width:120px;background-blend-mode: multiply;"></td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 25px;" colspan="7">DCS ENGINEERS & CONSULTANT Pvt. Ltd.</td>
				</tr>
				<tr>
					<td style="text-align: center;font-size: 15px;" colspan="7">(Formerly known as DC Consulant)</td>
				</tr>
				<tr>
					<td style="text-align: center;font-size: 13px;" colspan="7">Mobile : +91-7018819894, +91-9816755805,e-mail : officialdcspvtltd@gmail.com</td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 14px;" colspan="7">Regd. Office : VPO Taragarh (Rani Di K) Near Taragarh Palace Tehsil Baijnath</td>
				</tr>
				<tr>
					<td style="text-align: center;font-weight: bold;font-size: 14px;" colspan="7">District Kangra Himachal Pradesh (176081)</td>
				</tr>
				<tr>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;border-right: 1px solid;font-size: 20px;">CBR</td>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;font-size: 20px;" colspan="6"> ANALYSIS DATA SHEET </td>
					<td style="text-align: center;border-top: 1px solid;font-weight: bold;font-size: 20px;"> QSF-1001</td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="4"><b>&nbsp;Job Card No:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="4"><b>&nbsp;Test:&nbsp;</b></td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="4"><b>&nbsp;Sample Description:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="4"><b>&nbsp;Method:&nbsp;</b>
					</td>
				</tr>
				<tr>
					<td style="text-align: left;border-top: 1px solid;" colspan="2"><b>&nbsp;DOR:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left:1px solid;" colspan="2"><b>&nbsp;DOS:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left: 1px solid;" colspan="2"><b>&nbsp;DOC:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left:1px solid;" colspan="2"><b>&nbsp;Page No:&nbsp;</b></td>
				</tr>
				<tr>
					<td style=" text-align: left;border-top: 1px solid;" colspan="3"><b>&nbsp;Sample Qty:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left : 1px solid;" colspan="2"><b> &nbsp;Residual Sample:&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left : 1px solid;" colspan="3"><b>&nbsp;Sample Retention:&nbsp;</b></td>
				</tr>
				<tr>
					<td style=" text-align: left;border-top: 1px solid;" colspan="3"><b>&nbsp;MDD/OMC &nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left : 1px solid;" colspan="2"><b> &nbsp;Method of Compaction&nbsp;</b></td>
					<td style="text-align: left;border-top: 1px solid;border-left : 1px solid;" colspan="3"><b>&nbsp;Period of Soaking&nbsp;</b></td>
				</tr>
			</table>


			<br>
			<table align="center" style="width: 95%;text-align: center;border:1px solid black;font-family:calibri;border-collapse:collapse;" cellspacing="0" cellpadding="2px">
				<tr>
					<td style="border: 0px solid;font-weight:bold;width:15%;" colspan="6">CALIFORNIA BEARING RATIO (CBR) TEST (SOAKED/UNSOAKED)</td>
				</tr>
				<tr>
					<td style="border: 0px solid;font-weight:bold;width:15%;" colspan="6">(As Per IS: 2720 ,Part-16)</td>
				</tr>

				<tr>
					<td style="border:1px solid;width:25%;font-weight:bold;text-align: left;">No. of Blow</td>
					<td style="border:1px solid;width:10%;font-weight:bold;">Unit</td>
					<td style="border:1px solid;width:15%;font-weight:bold;"></td>
					<td style="border:1px solid;width:20%;font-weight:bold;"></td>
					<td style="border:1px solid;width:20%;font-weight:bold;"></td>
					<td style="border:1px solid;width:10%;font-weight:bold;">Remark</td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Mould No.</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Volume of Mould</td>
					<td style="border:1px solid;">cc</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Wt of Mould</td>
					<td style="border:1px solid;">gms</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Wt of Mould + Wet Soil</td>
					<td style="border:1px solid;">gms</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Wt of Wet Soil</td>
					<td style="border:1px solid;">gms</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Wet Density</td>
					<td style="border:1px solid;">gm/cc</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Moisture Content </td>
					<td style="border:1px solid;">%</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Dry Density </td>
					<td style="border:1px solid;">gm/cc</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">% Compaction </td>
					<td style="border:1px solid;">%</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border: 0px solid;width:15%;font-weight: bold; " colspan="6">FINAL MOISTURE CONTENT DETERMINATION</td>
				</tr>
				<tr>
					<td style="border:1px solid;width:25%;font-weight:bold;text-align: left;">No. of Blow</td>
					<td style="border:1px solid;width:10%;font-weight:bold;">Unit</td>
					<td style="border:1px solid;width:15%;font-weight:bold;"></td>
					<td style="border:1px solid;width:20%;font-weight:bold;"></td>
					<td style="border:1px solid;width:20%;font-weight:bold;"></td>
					<td style="border:1px solid;width:10%;font-weight:bold;"></td>


				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Container No.</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Wt of Cont. + Wet Soil</td>
					<td style="border:1px solid;">gms</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Wt of Cont. + Dry Soil</td>
					<td style="border:1px solid;">gms</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Wt of Empty Container</td>
					<td style="border:1px solid;">gms</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Wt of Water</td>
					<td style="border:1px solid;">gms</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
				<tr>
					<td style="border:1px solid;text-align: left;">Wet Dry Soil</td>
					<td style="border:1px solid;">gms</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
				</tr>
			</table>
			<table align="center" style="width: 95%;text-align: center;border:1px solid black; border-top:0px;font-family:calibri;border-collapse:collapse;" cellspacing="0" cellpadding="2px">
			<tr>
				<td style="border: 0px solid;width:15%;text-align: left; " colspan="6"><SPAN style="font-weight: bold;">TEST DATA</SPAN> &nbsp;(Proving Ring Multification Factor = 1 Div =  Kg)</td>
			</tr>
			<tr>
				<td style="border:1px solid;width:25%;font-weight:bold;text-align: left;">No. of Blow</td>
				<td style="border:1px solid;width:20%;font-weight:bold;" colspan="2"></td>
				<td style="border:1px solid;width:20%;font-weight:bold;" colspan="2"></td>
				<td style="border:1px solid;width:20%;font-weight:bold;" colspan="2"></td>
				<td style="border:1px solid;width:15%;font-weight:bold;"></td>
			</tr>
			<tr>
				<td style="border:1px solid;font-weight:bold;">Penetration mm</td>
				<td style="border:1px solid;font-weight:bold;">Divn.</td>
				<td style="border:1px solid;font-weight:bold;">Load (Kg)</td>
				<td style="border:1px solid;font-weight:bold;">Divn.</td>
				<td style="border:1px solid;font-weight:bold;">Load (Kg)</td>
				<td style="border:1px solid;font-weight:bold;">Divn.</td>
				<td style="border:1px solid;font-weight:bold;">Load (Kg)</td>
				<td style="border:1px solid;font-weight:bold;"></td>
			</tr>
			<tr>
				<td style="border:1px solid;">0.5</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
			</tr>
			<tr>
				<td style="border:1px solid;">1.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
			</tr>
			<tr>
				<td style="border:1px solid;">1.5</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
			</tr>
			<tr>
				<td style="border:1px solid;">2.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
			</tr>
			<tr>
				<td style="border:1px solid;">2.5</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
			</tr>
			<tr>
				<td style="border:1px solid;">3.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
			</tr>
			<tr>
				<td style="border:1px solid;">4.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
			</tr>
			<tr>
				<td style="border:1px solid;">5.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
			</tr>
				<tr>
					<td style="border:1px solid;">7.5</td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>
					<td style="border:1px solid;"></td>

			</tr>

			<tr>
				<td style="border:1px solid;">1.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>

			</tr>

			<tr>
				<td style="border:1px solid;">1.5</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>

			</tr>

			<tr>
				<td style="border:1px solid;">2.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>

			</tr>

			<tr>
				<td style="border:1px solid;">2.5</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>

			</tr>

			<tr>
				<td style="border:1px solid;">3.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>

			</tr>



			<tr>
				<td style="border:1px solid;">4.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>

			</tr>




			<tr>
				<td style="border:1px solid;">5.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>

			</tr>

			<tr>
				<td style="border:1px solid;">7.5</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>

			</tr>

			<tr>
				<td style="border:1px solid;">10.0</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>

			</tr>

			<tr>
				<td style="border:1px solid;">12.5</td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>
				<td style="border:1px solid;"></td>

			</tr>
			<tr>
				<td style="border:1px solid;font-weight: bold;">CBR%</td>
				<td style="border:1px solid;" colspan="2"></td>
				<td style="border:1px solid;" colspan="2"></td>
				<td style="border:1px solid;" colspan="2"></td>
				<td style="border:1px solid;"></td>

			</tr>

			<tr>
				<td style="border:1px solid;font-weight: bold;text-align: left;">CBR 2.5mm%</td>
				<td style="border:1px solid;" colspan="7"></td>


			</tr>

			<tr>
				<td style="border:1px solid;font-weight: bold;text-align: left;">CBR 5.0mm%</td>
				<td style="border:1px solid;" colspan="7"></td>


			</tr>



			</table>
			<br>
			<br>
			<br>
			<br>
			<br>

			<table style="width: 92%;" align="center">
				<tr>
					<td style="border: 0;text-align: left;font-size: 15px;font-family: 'calibri'"><b>Checked by</td></b>
					<td style="border: 0;text-align: right;font-size: 15px;font-family: 'calibri'"><b>Analyst</td></b>
				</tr>
			</table>



			<div class="pagebreak"></div>
		</page>


		<!--harsh end -->

		<table align="center" width="100%" cellpadding="0" style="font-size:11px;height:auto;font-family : Calibri;border: 1px solid;padding: 0;border-collapse: collapse;">
			<!-- header design -->
			<tr>
				<td style="text-align:center;font-size:16px; ">
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-top:1px solid;border-right:1px solid;border-left:1px solid;">
						<tr style="">
							<td style="width:30%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; DOC: STC/N/OS/001</td>
							<td style="width:20%;text-align:center;font-weight:bold; ">REV: 1</td>
							<td style="width:25%; font-weight:bold;">RD:- 01/01/2025</td>
							<td style="width:25%;font-weight:bold;">Page : 7</td>
						</tr>
					</table>
				</td>
			</tr>

			<tr>
				<td style="text-align:center;font-size:16px; ">
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">
						<tr style="">
							<td style="width:60%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; Prepared by: Technical Manager</td>
							<td style="width:40%;text-align:left;font-weight:bold; ">Approved by: Quality Manager</td>
						</tr>
					</table>
				</td>
			</tr>

			<tr>
				<td style="text-align:center;font-size:16px; ">
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">
						<tr style="">
							<td style="width:80%;padding-left:150px; text-align:center;font-weight:bold;padding-bottom:3px;padding-top:3px; ">STERN TESTING & CONSULTANCY PVT. LTD.</td>
							<td style="width:20%;text-align:center;font-weight:bold; " rowspan=5><img src="../images/mat_logo.png" style="height:40px;width:120px;background-blend-mode:multiply;"></td>
						</tr>
						<tr style="">
							<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">PLOT NO. G-2049, KADVANI FORGE,KISHAN GATE</td>
						</tr>
						<tr style="">
							<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">G.I.D.C.,KALAWAD ROAD,METODA,360021,RAJKOT</td>
						</tr>
					</table>
				</td>
			</tr>

			<tr>
				<td style="text-align:center;font-size:20px; ">
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:20px;font-family : Calibri;">
						<tr style="">
							<td style="width:100%;padding-bottom:10px;padding-top:10px; text-align:center;font-weight:bold;border-right:1px solid;border-left:1px solid; " colspan="3"><span style=""> OBSERVATION AND CALCULATION SHEET FOR TEST ON SOIL</td>
						</tr>
						<tr style="font-size:10px;">
							<td style="width:10%;font-weight:bold;text-align:center;border-top:1px solid; border-left:1px solid;">1</td>
							<td style="border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;border-top:1px solid; ">&nbsp;&nbsp; Job No.</td>
							<td style="border-left:1px solid;width:50%;border-top:1px solid;border-right:1px solid; ">&nbsp;&nbsp; </td>
						</tr>
						<tr style="font-size:10px;">
							<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">2</td>
							<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Laboratory No</td>
							<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
						</tr>
						<tr style="font-size:10px;">
							<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">3</td>
							<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of receipt of sample</td>
							<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
						</tr>
						<tr style="font-size:10px;">
							<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">4</td>
							<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of starting test</td>
							<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
						</tr>
						<tr style="font-size:10px;">
							<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">5</td>
							<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Probable date of completion</td>
							<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
						</tr>
					</table>
				</td>
			</tr>

			<tr>
				<td>
					<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">
						<tr>
							<td style="font-size: 14px;font-weight: bold;text-align: center;padding: 2px;text-transform: uppercase;border: 1px solid;">LIGHT COMPACTION (PROCTOR) TEST As Per IS: 2720 (Part-7): 1980 Reaffirmed: 2021, Clause No :-5-Light Compaction</td>
						</tr>
						<tr>
							<td style="padding: 1px;border: 1px solid;"></td>
						</tr>
					</table>
				</td>
			</tr>

			<tr>
				<td>
					<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-bottom:0px solid;">
						<tr>
							<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Amount of Sample Taken :-</td>
							<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;width: 10%;">gm</td>
							<td style="width:30%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; DOC: STC/N/OS/001</td>
							<td style="width:20%;text-align:center;font-weight:bold; ">REV: 1</td>
							<td style="width:25%; font-weight:bold;">RD:- 01/01/2025</td>
							<td style="width:25%;font-weight:bold;">Page : 7</td>
						</tr>
					</table>
				</td>
			</tr>

			<tr>
				<td style="text-align:center;font-size:16px; ">
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">
						<tr style="">
							<td style="width:60%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; Prepared by: Technical Manager</td>
							<td style="width:40%;text-align:left;font-weight:bold; ">Approved by: Quality Manager</td>
						</tr>
					</table>
				</td>
			</tr>

			<tr>
				<td style="text-align:center;font-size:16px; ">
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">
						<tr style="">
							<td style="width:80%;padding-left:150px; text-align:center;font-weight:bold;padding-bottom:3px;padding-top:3px; ">STERN TESTING & CONSULTANCY PVT. LTD.</td>
							<td style="width:20%;text-align:center;font-weight:bold; " rowspan=5><img src="../images/mat_logo.png" style="height:40px;width:120px;background-blend-mode:multiply;"></td>
						</tr>
						<tr style="">
							<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">PLOT NO. G-2049, KADVANI FORGE,KISHAN GATE</td>
						</tr>
						<tr style="">
							<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">G.I.D.C.,KALAWAD ROAD,METODA,360021,RAJKOT</td>
						</tr>
					</table>
				</td>
			</tr>

				<tr>
					<td style="text-align:center;font-size:20px; ">
						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:20px;font-family : Calibri;">
							<tr style="">
								<td style="width:100%;padding-bottom:10px;padding-top:10px; text-align:center;font-weight:bold;border-right:1px solid;border-left:1px solid; " colspan="3"><span style=""> OBSERVATION AND CALCULATION SHEET FOR TEST ON SOIL</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="width:10%;font-weight:bold;text-align:center;border-top:1px solid; border-left:1px solid;">1</td>
								<td style="border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;border-top:1px solid; ">&nbsp;&nbsp; Job No.</td>
								<td style="border-left:1px solid;width:50%;border-top:1px solid;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">2</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Laboratory No</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">3</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of receipt of sample</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">4</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of starting test</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">5</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Probable date of completion</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">
							<tr>
								<td style="font-size: 14px;font-weight: bold;text-align: center;padding: 2px;text-transform: uppercase;border: 1px solid;">LIGHT COMPACTION (PROCTOR) TEST As Per IS: 2720 (Part-7): 1980 Reaffirmed: 2021, Clause No :-5-Light Compaction</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-bottom:0px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Amount of Sample Taken :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;width: 10%;">gm</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Type Of Test:-</td>
								<td style="padding: 2px; font-weight: bold; text-align: left;">&nbsp;&nbsp; Light Compation</td>
								<td style="width: 5%;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Diameter of Mould :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">cm</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Volume of mould (Vm) :-</td>
								<td style="padding: 2px; font-weight: bold; text-align: left;">&nbsp;&nbsp; cm</td>
								<td style="width: 5%;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0; padding-bottom:15px;">Height of Mould :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0; padding-bottom:15px;">cm</td>
								<td></td>
								<td></td>
								<td style="width: 5%;"></td>
							</tr>
						</table>
					</td>
				</tr>

				<tr>
					<td style="border: 2px solid; border-top:0px solid; border-bottom:0px solid;">
						<table align="center" width="60%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 2px solid;border-right: 2px solid; border-top:2px solid; border-bottom:2px solid;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="3">Sr.No.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> Full Weight of Mould </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> Empty Weight of Mould </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> Bulk Density </td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> m<sub>2</sub> </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> m<sub>1</sub> </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> Xm = (m<sub>2</sub>-m<sub>1</sub>) / Vm<sub>2</sub></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> gm </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> gm </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> g / cm<sup>3</sup> </td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"> 1</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">2</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">3</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">4</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">5</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">6</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">7</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">8</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">9</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>

				<tr>
					<td style="border: 2px solid; border-top:0px solid; border-bottom:0px solid;">
						<table align="center" width="82%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 2px solid;
						border-right: 2px solid; border-top:1px solid; margin-top: 10px; border-bottom: 2px solid; margin-bottom: 5px;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid; border-bottom: 2px solid;" rowspan="5">Sr.No.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid; border-bottom: 2px solid;" rowspan="5" colspan="">Container No.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="3">Container Weight</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="2"> Container Weight<br>+ Wet Sample<br> Weight </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="2">Container Weight<br>+ Dry Sample<br>Weight </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="2">Moisture Content </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid; width: 15%;" rowspan="2"> Dry Density </td>
							</tr>
							<tr>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2"> m<sub>2</sub> </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2px;"> m<sub>3</sub> </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2"> W = (m<sub>2</sub>-m<sub>3</sub>) / (m<sub>2</sub>-m<sub>3</sub>)</u> X 100 </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2"> γ<sup>d</sup> = <u>100γm</u> <br> &nbsp; &nbsp; &nbsp; &nbsp; 10 + w </td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> m<sub>1</sub> </td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; padding: 2px;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; padding: 2px;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; padding: 2px;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; border-top: 2px solid; padding: 2px;">%</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; border-top: 2px solid; padding: 2px;">g / cm<sup>3</sup></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">1</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">2</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">3</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">4</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">5</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">6</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">7</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">8</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">9</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">10</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">11</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">12</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">12</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">13</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">14</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">15</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">16</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">17</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">18</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">19</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">20</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">21</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">22</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">23</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">24</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">25</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">26</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">
							<tr>
								<td style="border-left: 1px solid;width: 10%;"></td>
								<td style="">Maximum Dry Density (MDD) :-</td>
								<td style=""> g/cm<sup>2</sup></td>
								<td style="">Optimum Moisture Content (OMC) :-</td>
								<td style=""> %</td>
								<td style="border-right: 1px solid;width: 10%;"></td>
							</tr>
							<tr>
								<td colspan="6" style="padding: 6px;border-left: 1px solid; border-right: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>

				<!-- footer design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border: 1px solid; ">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;width: 15%;border: 0px solid;">Checked By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding:5px;width: 12%;border: 0px solid;">Tested By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
							</tr>
							<tr>
								<td style="height: 35px;border: 1px solid;border-right: 1px solid; border-bottom:0px; border-top:1px solid;" colspan="4"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
					</td>
				</tr>
			</table>

			<div class="pagebreak"></div>

			<br><br>

			<!-- heavy Compaction -->
			<table align="center" width="100%" cellpadding="0" style="font-size:11px;height:auto;font-family : Calibri;border: 1px solid;padding: 0;border-collapse: collapse;">
				<!-- header design -->
				<tr>
					<td style="text-align:center;font-size:16px; ">
						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-top:1px solid;border-right:1px solid;border-left:1px solid;">
							<tr style="">
								<td style="width:30%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; DOC: STC/N/OS/001</td>
								<td style="width:20%;text-align:center;font-weight:bold; ">REV: 1</td>
								<td style="width:25%; font-weight:bold;">RD:- 01/01/2025</td>
								<td style="width:25%;font-weight:bold;">Page : 7</td>
							</tr>
						</table>
					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:60%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; Prepared by: Technical Manager</td>
								<td style="width:40%;text-align:left;font-weight:bold; ">Approved by: Quality Manager</td>
							</tr>

						</table>

					</td>
				</tr>
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:80%;padding-left:150px; text-align:center;font-weight:bold;padding-bottom:3px;padding-top:3px; ">STERN TESTING & CONSULTANCY PVT. LTD.</td>
								<td style="width:20%;text-align:center;font-weight:bold; " rowspan=5><img src="../images/mat_logo.png" style="height:40px;width:120px;background-blend-mode:multiply;"></td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">PLOT NO. G-2049, KADVANI FORGE,KISHAN GATE</td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">G.I.D.C.,KALAWAD ROAD,METODA,360021,RAJKOT</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:20px; ">
						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:20px;font-family : Calibri;">
							<tr style="">
								<td style="width:100%;padding-bottom:10px;padding-top:10px; text-align:center;font-weight:bold;border-right:1px solid;border-left:1px solid; " colspan="3"><span style=""> OBSERVATION AND CALCULATION SHEET FOR TEST ON SOIL</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="width:10%;font-weight:bold;text-align:center;border-top:1px solid; border-left:1px solid;">1</td>
								<td style="border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;border-top:1px solid; ">&nbsp;&nbsp; Job No.</td>
								<td style="border-left:1px solid;width:50%;border-top:1px solid;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">2</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Laboratory No</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">3</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of receipt of sample</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">4</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of starting test</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">5</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Probable date of completion</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">

							<tr>
								<td style="font-size: 14px;font-weight: bold;text-align: center;padding: 2px;text-transform: uppercase;border: 1px solid;">HEAVY COMPACTION (PROCTOR) TEST As Per IS: 2720 (Part-8): 1983 Reaffirmed: 2020, Clause No:-5-Heavy Compaction</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-bottom:0px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Amount of Sample Taken :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;width: 10%;">gm</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Type Of Test:-</td>
								<td style="padding: 2px; font-weight: bold; text-align: left;">&nbsp;&nbsp; Heavy Compaction</td>
								<td style="width: 5%;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Diameter of Mould :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">cm</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Volume of mould (Vm) :-</td>
								<td style="padding: 2px; font-weight: bold; text-align: left;">&nbsp;&nbsp; cm</td>
								<td style="width: 5%;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0; padding-bottom:15px;">Height of Mould :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0; padding-bottom:15px;"> cm</td>
								<td></td>
								<td></td>
								<td style="width: 5%;"></td>
							</tr>
						</table>
					</td>
				</tr>

				<tr>
					<td style="border: 2px solid; border-top:0px solid; border-bottom:0px solid;">
						<table align="center" width="60%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 2px solid;border-right: 2px solid; border-top:2px solid; border-bottom:2px solid;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="3">Sr.No.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> Full Weight of Mould </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> Empty Weight of Mould </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> Bulk Density </td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> m<sub>2</sub> </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> m<sub>1</sub> </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> Xm = (m<sub>2</sub>-m<sub>1</sub>) / Vm<sub>2</sub></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> gm </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> gm </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> g / cm<sup>3</sup> </td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"> 1</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">2</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"> 3 </td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">4 </td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"> 5</td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;">6 </td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"> 7 </td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"> 8 </td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"> 9 </td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>

				<tr>
					<td style="border: 2px solid; border-top:0px solid; border-bottom:0px solid;">
						<table align="center" width="82%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 2px solid;
					border-right: 2px solid; border-top:1px solid; margin-top: 10px; border-bottom: 2px solid; margin-bottom: 5px;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid; border-bottom: 2px solid;" rowspan="5">Sr.No.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid; border-bottom: 2px solid;" rowspan="5" colspan="">Container No.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="3">Container Weight</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="2"> Container Weight<br>+ Wet Sample<br> Weight </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="2">Container Weight<br>+ Dry Sample<br>Weight </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="2">Moisture Content </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid; width: 15%;" rowspan="2"> Dry Density </td>
							</tr>
							<tr>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2"> m<sub>2</sub> </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2px;"> m<sub>3</sub> </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2"> W = (m<sub>2</sub>-m<sub>3</sub>) / (m<sub>2</sub>-m<sub>3</sub>)</u> X 100 </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2"> γ<sup>d</sup> = <u>100γm</u> <br> &nbsp; &nbsp; &nbsp; &nbsp; 10 + w </td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> m<sub>1</sub> </td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; padding: 2px;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; padding: 2px;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; padding: 2px;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; border-top: 2px solid; padding: 2px;">%</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; border-top: 2px solid; padding: 2px;">g / cm<sup>3</sup></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
							<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">
							<tr>
								<td style="border-left: 1px solid;width: 10%;"></td>
								<td style="">Maximum Dry Density (MDD) :-</td>
								<td style=""></td>
								<td style="">Optimum Moisture Content (OMC) :-</td>
								<td style=""></td>
								<td style="border-right: 1px solid;width: 10%;"></td>
							</tr>
							<tr>
								<td colspan="6" style="padding: 6px;border-left: 1px solid; border-right: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>

				<!-- footer design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border: 1px solid; ">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;width: 15%;border: 0px solid;">Checked By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding:5px;width: 12%;border: 0px solid;">Tested By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
							</tr>
							<tr>
								<td style="height: 35px;border: 1px solid;border-right: 1px solid; border-bottom:0px; border-top:1px solid;" colspan="4"></td>
							</tr>

						</table>
					</td>
				</tr>

			</table>

			<div class="pagebreak"></div><br><br>

	
			<table align="center" width="100%" cellpadding="0" style="font-size:11px;height:auto;font-family : Calibri;border: 1px solid;padding: 0;border-collapse: collapse;">
				<!-- header design -->
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-top:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:30%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; DOC: STC/N/OS/001</td>
								<td style="width:20%;text-align:center;font-weight:bold; ">REV: 1</td>
								<td style="width:25%; font-weight:bold;">RD:- 01/01/2025</td>
								<td style="width:25%;font-weight:bold;">Page : 7</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:60%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; Prepared by: Technical Manager</td>
								<td style="width:40%;text-align:left;font-weight:bold; ">Approved by: Quality Manager</td>
							</tr>

						</table>

					</td>
				</tr>
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:80%;padding-left:150px; text-align:center;font-weight:bold;padding-bottom:3px;padding-top:3px; ">STERN TESTING & CONSULTANCY PVT. LTD.</td>
								<td style="width:20%;text-align:center;font-weight:bold; " rowspan=5><img src="../images/mat_logo.png" style="height:40px;width:120px;background-blend-mode:multiply;"></td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">PLOT NO. G-2049, KADVANI FORGE,KISHAN GATE</td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">G.I.D.C.,KALAWAD ROAD,METODA,360021,RAJKOT</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:20px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:20px;font-family : Calibri;">

							<tr style="">

								<td style="width:100%;padding-bottom:10px;padding-top:10px; text-align:center;font-weight:bold;border-right:1px solid;border-left:1px solid; " colspan="3"><span style=""> OBSERVATION AND CALCULATION SHEET FOR TEST ON SOIL</td>
							</tr>
							<?php
							if ($row_select_pipe['lab_no'] != "") {
								$cnt = 1;

							?>
								<tr style="font-size:10px;">

									<td style="width:10%;font-weight:bold;text-align:center;border-top:1px solid; border-left:1px solid;"><?php echo $cnt++; ?></td>
									<td style="border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;border-top:1px solid; ">&nbsp;&nbsp; Job No.</td>
									<td style="border-left:1px solid;width:50%;border-top:1px solid;border-right:1px solid; ">&nbsp;&nbsp; <?php echo $row_select_pipe['lab_no']; ?></td>
								</tr>
							<?php }
							if ($job_no != "") {
							?>
								<tr style="font-size:10px;">

									<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; "><?php echo $cnt++; ?></td>
									<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Laboratory No</td>
									<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; <?php echo $job_no; ?></td>
								</tr>
							<?php }
							//if($job_no!=""){
							?>
							<tr style="font-size:10px;">

								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; "><?php echo $cnt++; ?></td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of receipt of sample</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; <?php echo date('d-m-Y', strtotime($rec_sample_date)); ?></td>
							</tr>
							<tr style="font-size:10px;">

								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; "><?php echo $cnt++; ?></td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of starting test</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; <?php echo date('d-m-Y', strtotime($start_date)); ?></td>
							</tr>
							<tr style="font-size:10px;">

								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; "><?php echo $cnt++; ?></td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Probable date of completion</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; <?php echo date('d-m-Y', strtotime($end_date)); ?></td>
							</tr>
						</table>

					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">

							<tr>
								<td style="font-size: 14px;font-weight: bold;text-align: center;padding: 2px;text-transform: uppercase;border: 1px solid;">UNCONFINED COMPRESSIVE STRENGTH TEST As Per IS: 2720 (Part-10): 1991 Reaffirmed: 2020, Clause No:- 1.1</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Load cell Capacity:-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["str1"] ?> KN</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Load cell Least Count:-</td>
								<td style="padding: 2px; font-weight: bold;"><?php echo $row_select_pipe["str2"] ?> KN</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Length of Specimen - L<sub>o</sub> :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["str3"] ?> mm</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Diameter of Specimen - Do :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["str4"] ?> mm</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Original Cross Sectional Area - Ao :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["str5"] ?> cm<sup>2</sup></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Initial Volume - Vo :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["str6"] ?> cm<sup>3</sup></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Initial Mass of Specimen :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["str7"] ?> gm</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Initial Density :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["str8"] ?> gm/cm³</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Initial Water Content :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["str9"] ?> %</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Weight of Specimen after Test :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["str10"] ?> gm</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0; padding-bottom: 20px;">Rate of Strain :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0; padding-bottom: 20px;"><?php echo $row_select_pipe["str11"] ?> mm/min</td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<?php $cnt = 1; ?>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-top:1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid; border-bottom: 2px solid;" rowspan="4">Time</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid; border-bottom: 2px solid;" rowspan="4" colspan="2">Load</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid; height:40px;" rowspan="3">Displacement</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="2">Axial Strain</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="2">Corrected Area</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top: 2px solid;" rowspan="2">Unconfined Compressive<br> Strength</td>
							</tr>
							<tr>

							</tr>
							<tr>
								<!-- <td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Load</td> -->
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2"> E = ΔL / Lo </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2px;"> A = Ao / (1 - E) </td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2"> σ<sub>c</sub> = P / A</td>
								<!-- <td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Load</td> -->
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"> ΔL </td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; padding: 2px;">min</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; padding: 2px;">KN</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; padding: 2px;">kg</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; border-top: 2px solid; padding: 2px;">mm</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; border-top: 2px solid; padding: 2px;">--</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; border-top: 2px solid; padding: 2px;">cm²</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid; border-bottom: 2px solid; border-top: 2px solid; padding: 2px;">kg / cm²</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc1"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc2"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc3"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre1"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre2"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre67"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.25</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc4"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc5"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc6"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre3"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre4"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre68"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc7"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc8"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc9"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre5"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre6"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre69"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.75</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc10"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc11"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc12"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre7"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre8"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre70"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">1.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc13"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc14"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc15"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre9"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre10"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre71"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">1.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc16"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc17"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc18"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre11"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre12"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre72"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">2.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc19"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc20"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc21"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre13"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre14"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre73"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">2.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc22"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc23"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc24"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre15"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre16"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre74"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">3.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc25"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc26"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc27"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre17"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre18"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre75"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">3.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc28"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc29"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc30"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre19"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre20"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre76"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">4.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc31"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc32"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc33"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre21"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre22"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre77"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">4.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc34"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc35"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc36"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre23"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre24"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre78"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">5.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc37"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc38"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc39"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre25"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre26"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre79"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">5.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc40"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc41"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc42"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre27"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre28"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre80"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">6.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc43"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc44"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc45"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre29"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre30"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre81"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">6.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc46"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc47"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc48"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre31"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre32"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre82"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">7.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc50"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc51"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc52"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre33"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre34"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre83"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">7.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc53"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc54"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc55"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre35"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre36"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre84"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">8.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc56"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc57"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc58"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre37"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre38"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre85"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">8.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc59"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc60"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc61"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre39"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre40"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre86"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">9.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc62"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc63"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc64"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre41"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre42"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre87"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">9.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc65"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc66"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc67"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre43"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre44"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre88"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">10.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc68"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc69"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc70"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre45"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre46"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre89"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">10.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc71"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc72"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc73"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre47"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre48"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre90"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">11.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc74"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc75"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc76"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre49"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre50"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre91"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">11.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc77"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc78"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc79"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre51"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre52"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre92"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">12.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc80"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc81"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc82"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre53"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre54"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre93"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">12.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc83"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc84"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc85"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre55"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre56"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre94"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">13.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc86"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc87"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc88"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre57"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre58"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre95"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">13.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc89"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc90"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc91"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre59"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre60"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre96"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">14.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc92"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc93"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc94"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre61"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre62"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre97"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">14.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc95"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc96"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc97"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre63"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre64"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre98"] ?></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">15.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc98"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc99"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["unc100"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre65"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre66"] ?></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"><?php echo $row_select_pipe["corre99"] ?></td>
							</tr>
						</table>
					</td>
				</tr>
				<!-- footer design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border: 1px solid; ">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;width: 15%;border: 0px solid;">Checked By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding:5px;width: 12%;border: 0px solid;">Tested By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
							</tr>
							<tr>
								<td style="height: 35px;border: 1px solid;border-right: 1px solid; border-bottom:0px; border-top:1px solid;" colspan="4"></td>
							</tr>

						</table>
					</td>
				</tr>

			</table>

			<div class="pagebreak"></div><br><br>
		
			<table align="center" width="100%" cellpadding="0" style="font-size:11px;height:auto;font-family : Calibri;border: 1px solid;padding: 0;border-collapse: collapse;">
				<!-- header design -->
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-top:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:30%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; DOC: STC/N/OS/001</td>
								<td style="width:20%;text-align:center;font-weight:bold; ">REV: 1</td>
								<td style="width:25%; font-weight:bold;">RD:- 01/01/2025</td>
								<td style="width:25%;font-weight:bold;">Page : 7</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:60%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; Prepared by: Technical Manager</td>
								<td style="width:40%;text-align:left;font-weight:bold; ">Approved by: Quality Manager</td>
							</tr>

						</table>

					</td>
				</tr>
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:80%;padding-left:150px; text-align:center;font-weight:bold;padding-bottom:3px;padding-top:3px; ">STERN TESTING & CONSULTANCY PVT. LTD.</td>
								<td style="width:20%;text-align:center;font-weight:bold; " rowspan=5><img src="../images/mat_logo.png" style="height:40px;width:120px;background-blend-mode:multiply;"></td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">PLOT NO. G-2049, KADVANI FORGE,KISHAN GATE</td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">G.I.D.C.,KALAWAD ROAD,METODA,360021,RAJKOT</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:20px;">
						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:20px;font-family:Calibri;">
							<tr>
								<td style="width:100%;padding:10px 0;text-align:center;font-weight:bold;border:1px solid;" colspan="3">OBSERVATION AND CALCULATION SHEET FOR TEST ON SOIL</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="width:10%;font-weight:bold;text-align:center;border:1px solid;"></td>
								<td style="width:40%;text-align:left;padding:3px;border:1px solid;">&nbsp;&nbsp; Job No.</td>
								<td style="width:50%;border:1px solid;">&nbsp;&nbsp;</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="width:10%;font-weight:bold;text-align:center;border:1px solid;"></td>
								<td style="width:40%;text-align:left;padding:3px;border:1px solid;">&nbsp;&nbsp; Laboratory No</td>
								<td style="width:50%;border:1px solid;">&nbsp;&nbsp;</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="width:10%;font-weight:bold;text-align:center;border:1px solid;"></td>
								<td style="width:40%;text-align:left;padding:3px;border:1px solid;">&nbsp;&nbsp; Date of receipt of sample</td>
								<td style="width:50%;border:1px solid;">&nbsp;&nbsp;</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="width:10%;font-weight:bold;text-align:center;border:1px solid;"></td>
								<td style="width:40%;text-align:left;padding:3px;border:1px solid;">&nbsp;&nbsp; Date of starting test</td>
								<td style="width:50%;border:1px solid;">&nbsp;&nbsp;</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="width:10%;font-weight:bold;text-align:center;border:1px solid;"></td>
								<td style="width:40%;text-align:left;padding:3px;border:1px solid;">&nbsp;&nbsp; Probable date of completion</td>
								<td style="width:50%;border:1px solid;">&nbsp;&nbsp;</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">
							<tr>
								<td style="font-size: 14px;font-weight: bold;text-align: center;padding: 2px;text-transform: uppercase;border: 1px solid;">Field Dry Density & Field Moisture Content (I.S.: 2720-Part 29-1995, I.S.: 2720-Part 2-1997)</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;"></td>
							</tr>
						</table>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="padding: 1px;" colspan="2">Sample Extracted from: Shelby / Corecutter</td>
							</tr>
						</table>
					</td>
				</tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-bottom: 2px solid;" rowspan="2">(M2-M3)/(M3- <br> M1)</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">mtr.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">cm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">cm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">cm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">(Vs), cm³</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">(We), cm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">(Ws), cm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">(Ws-We)/Vs</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">M1, gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">M2, gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">M3, gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">gb/(1+MC/100)</td>
							</tr>

							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;" colspan="17"></td>
							</tr>
						</table>
					</td>
				</tr>
				<!-- footer design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border: 1px solid; ">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;width: 15%;border: 0px solid;">Checked By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding:5px;width: 12%;border: 0px solid;">Tested By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
							</tr>
							<tr>
								<td style="height: 35px;border: 1px solid;border-right: 1px solid; border-bottom:0px; border-top:1px solid;" colspan="4"></td>
							</tr>

						</table>
					</td>
				</tr>

			</table>


			<div class="pagebreak"></div>
			<br><br><br><br>

		
			<table align="center" width="100%" cellpadding="0" style="font-size:11px;height:auto;font-family : Calibri;border: 1px solid;padding: 0;border-collapse: collapse;">
				<!-- header design -->
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-top:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:30%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; DOC: STC/N/OS/001</td>
								<td style="width:20%;text-align:center;font-weight:bold; ">REV: 1</td>
								<td style="width:25%; font-weight:bold;">RD:- 01/01/2025</td>
								<td style="width:25%;font-weight:bold;">Page : 7</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:60%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; Prepared by: Technical Manager</td>
								<td style="width:40%;text-align:left;font-weight:bold; ">Approved by: Quality Manager</td>
							</tr>

						</table>

					</td>
				</tr>
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:80%;padding-left:150px; text-align:center;font-weight:bold;padding-bottom:3px;padding-top:3px; ">STERN TESTING & CONSULTANCY PVT. LTD.</td>
								<td style="width:20%;text-align:center;font-weight:bold; " rowspan=5><img src="../images/mat_logo.png" style="height:40px;width:120px;background-blend-mode:multiply;"></td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">PLOT NO. G-2049, KADVANI FORGE,KISHAN GATE</td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">G.I.D.C.,KALAWAD ROAD,METODA,360021,RAJKOT</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:20px; ">
						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:20px;font-family : Calibri;">
							<tr style="">
								<td style="width:100%;padding-bottom:10px;padding-top:10px; text-align:center;font-weight:bold;border-right:1px solid;border-left:1px solid; " colspan="3"><span style=""> OBSERVATION AND CALCULATION SHEET FOR TEST ON SOIL</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="width:10%;font-weight:bold;text-align:center;border-top:1px solid; border-left:1px solid;">1</td>
								<td style="border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;border-top:1px solid; ">&nbsp;&nbsp; Job No.</td>
								<td style="border-left:1px solid;width:50%;border-top:1px solid;border-right:1px solid; ">&nbsp;&nbsp; LAB123</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">2</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Laboratory No</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; JOB456</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">3</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of receipt of sample</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; 01-01-2024</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">4</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of starting test</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; 02-01-2024</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">5</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Probable date of completion</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; 03-01-2024</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">
							<tr>
								<td style="font-size: 14px;font-weight: bold;text-align: center;padding: 2px;text-transform: uppercase;border: 1px solid;">SHRINKAGE LIMIT TEST As Per IS: 2720 (Part-6): 1972 Reaffirmed: 2021, Clause No.5</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<!-- table design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;border-bottom: 2px solid;" rowspan="2">Sr. <br>No.</td>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;border-bottom: 2px solid;" rowspan="2">Description</td>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;border-bottom: 2px solid;" rowspan="2">Unit</td>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">Results</td>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">Soil</td>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">Height</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">i</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">ii</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-bottom: 2px solid;">iii</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">1</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Weight of Shrinkage Dish - W₁</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">2</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Weight of Shrinkage Dish with Wet Soil Pat - W₂</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">3</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Weight of Shrinkage Dish with Dry Soil Pat - W3</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">4</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Weight of Oven Dry Soil Pat - W = (W3-W₁)</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">5</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Weight of Water - Ww = (W₂-W3)</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">6</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Moisture Content of Wet Soil Pat-W(W₂-W3)/(W3-W₁) x 100</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">%</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">7</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Weight of Mercury Filling in Shrinkage Dish</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">8</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Density of Mercury</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">g/cm³</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">9</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Volume of Shrinkage Dish - V</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">cm³</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">10</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Weight of Mercury displaced by Dry Soil Pat</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">11</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Volume of Dry Soil Pat - V<sub>0</sub></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">cm³</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">12</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Shrinkage Limit-W [W-{(V-V)/W}] X 100</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">%</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">13</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Shrinkage Ratio - R = W<sub>0</sub>/V<sub>0</sub></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">--</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">14</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Average Shrinkage Limit</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">%</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" colspan="3"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;">15</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Average Shrinkage Ratio</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">--</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" colspan="3"></td>
							</tr>


						</table>
					</td>
				</tr>
				<!-- footer design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border: 1px solid; ">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;width: 15%;border: 0px solid;">Checked By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding:5px;width: 12%;border: 0px solid;">Tested By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
							</tr>
							<tr>
								<td style="height: 35px;border: 1px solid;border-right: 1px solid; border-bottom:0px; border-top:1px solid;" colspan="4"></td>
							</tr>

						</table>
					</td>
				</tr>

			</table>

			<div class="pagebreak"></div>
			<br><br><br><br>

		<table align="center" width="100%" cellpadding="0" style="font-size:11px;height:auto;font-family : Calibri;border: 1px solid;padding: 0;border-collapse: collapse;">
			<!-- header design -->
			<tr>
				<td style="text-align:center;font-size:16px;">
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-top:1px solid;border-right:1px solid;border-left:1px solid;">
						<tr>
							<td style="width:30%;font-weight:bold;padding-bottom:2px;padding-top:2px;">&nbsp;&nbsp; DOC: STC/N/OS/001</td>
							<td style="width:20%;text-align:center;font-weight:bold;">REV: 1</td>
							<td style="width:25%; font-weight:bold;">RD:- 01/01/2025</td>
							<td style="width:25%;font-weight:bold;">Page : 7</td>
						</tr>
					</table>
				</td>
			</tr>

			<tr>
				<td style="text-align:center;font-size:16px;">
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">
						<tr>
							<td style="width:60%;font-weight:bold;padding-bottom:2px;padding-top:2px;">&nbsp;&nbsp; Prepared by: Technical Manager</td>
							<td style="width:40%;text-align:left;font-weight:bold;">Approved by: Quality Manager</td>
						</tr>
					</table>
				</td>
			</tr>

			<tr>
				<td style="text-align:center;font-size:16px;">
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">
						<tr>
							<td style="width:80%;padding-left:150px; text-align:center;font-weight:bold;padding-bottom:3px;padding-top:3px;">STERN TESTING & CONSULTANCY PVT. LTD.</td>
							<td style="width:20%;text-align:center;font-weight:bold;" rowspan=5><img src="../images/mat_logo.png" style="height:40px;width:120px;background-blend-mode:multiply;"></td>
						</tr>
						<tr>
							<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px;">PLOT NO. G-2049, KADVANI FORGE,KISHAN GATE</td>
						</tr>
						<tr>
							<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px;">G.I.D.C.,KALAWAD ROAD,METODA,360021,RAJKOT</td>
						</tr>
					</table>
				</td>
			</tr>

			<tr>
				<td style="text-align:center;font-size:20px;">
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:20px;font-family : Calibri;">
						<tr>
							<td style="width:100%;padding-bottom:10px;padding-top:10px; text-align:center;font-weight:bold;border-right:1px solid;border-left:1px solid;" colspan="3"><span> OBSERVATION AND CALCULATION SHEET FOR TEST ON SOIL</span></td>
						</tr>
						<tr style="font-size:10px;">
							<td style="width:10%;font-weight:bold;text-align:center;border-top:1px solid; border-left:1px solid;">1</td>
							<td style="border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;border-top:1px solid;">&nbsp;&nbsp; Job No.</td>
							<td style="border-left:1px solid;width:50%;border-top:1px solid;border-right:1px solid;">&nbsp;&nbsp; LAB123</td>
						</tr>
						<tr style="font-size:10px;">
							<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid;">2</td>
							<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;">&nbsp;&nbsp; Laboratory No</td>
							<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid;">&nbsp;&nbsp; LAB456</td>
						</tr>
						<tr style="font-size:10px;">
							<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid;">3</td>
							<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;">&nbsp;&nbsp; Date of receipt of sample</td>
							<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid;">&nbsp;&nbsp; 01-01-2024</td>
						</tr>
						<tr style="font-size:10px;">
							<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid;">4</td>
							<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;">&nbsp;&nbsp; Date of starting test</td>
							<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid;">&nbsp;&nbsp; 02-01-2024</td>
						</tr>
						<tr style="font-size:10px;">
							<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid;">5</td>
							<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;">&nbsp;&nbsp; Probable date of completion</td>
							<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid;">&nbsp;&nbsp; 03-01-2024</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>

					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">

							<tr>
								<td style="font-size: 14px;font-weight: bold;text-align: center;padding: 2px;text-transform: uppercase;border: 1px solid;">CONSOLIDATION TEST As Per IS: 2720 (Part-15): 1965 Reaffirmed: 2021</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Dial Guage No:-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"></td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Consolidometer No.</td>
								<td style="padding: 2px;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Sample Type :-</td>
								<td style="padding: 2px;">Remoulded/Undisturbed</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;" colspan="4"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Density of Soil :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"> gm/cc</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Moisture Content :-</td>
								<td style="padding: 2px;"> %</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Mass of Soil taken :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"> gm</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Amount of water taken :-</td>
								<td style="padding: 2px;"> gm</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Specific Gravity of Soil :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"></td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Volume of Consolidometer :-</td>
								<td style="padding: 2px;"> cm³</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Area of Specimen :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"> cm²</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Weight of Wet Specimen After Test :-</td>
								<td style="padding: 2px;"> gm</td>
							</tr>
							<tr>
								<td></td>
								<td></td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Weight of Dry Specimen After Test :-</td>
								<td style="padding: 2px;"> gm</td>
							</tr>
						</table>
					</td>
				</tr>
				<!-- table design -->
				<tr>
					<td>
						<?php $cnt = 1; ?>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-top:2px solid;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;" rowspan="6">Sr. <br>No.</td>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;" colspan="9">Description</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;border: 1px solid;" colspan="2">Starting Date :-</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;border: 1px solid;" colspan="2">Starting Time :-</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;border: 1px solid;" colspan="2">Pressure Increment kg/cm²</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.10</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.20</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.40</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.80</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">1.60</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">3.20</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">6.40</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;border: 1px solid;">Elapsed Time</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2">vt</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>

							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;border: 1px solid;">minute</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;">1</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.25</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.50</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.50</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.71</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">1.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">1.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">2.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">1.41</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">4.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">2.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">8.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">2.83</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">15.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">3.87</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">30.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">5.48</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">60.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">7.75</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">120.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">10.95</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">240.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">15.49</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">480.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">21.91</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 5px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">1440.00</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">37.95</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<!-- footer design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border: 1px solid; ">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;width: 15%;border: 0px solid;">Checked By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding:5px;width: 12%;border: 0px solid;">Tested By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
							</tr>
							<tr>
								<td style="height: 35px;border: 1px solid;border-right: 1px solid; border-bottom:0px; border-top:1px solid;" colspan="4"></td>
							</tr>

						</table>
					</td>
				</tr>

			</table>

			<div class="pagebreak"></div>
			<br><br>
		

			<table align="center" width="100%" cellpadding="0" style="font-size:11px;height:auto;font-family : Calibri;border: 1px solid;padding: 0;border-collapse: collapse;">
				<!-- header design -->
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-top:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:30%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; DOC: STC/N/OS/001</td>
								<td style="width:20%;text-align:center;font-weight:bold; ">REV: 1</td>
								<td style="width:25%; font-weight:bold;">RD:- 01/01/2025</td>
								<td style="width:25%;font-weight:bold;">Page : 7</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:60%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; Prepared by: Technical Manager</td>
								<td style="width:40%;text-align:left;font-weight:bold; ">Approved by: Quality Manager</td>
							</tr>

						</table>

					</td>
				</tr>
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:80%;padding-left:150px; text-align:center;font-weight:bold;padding-bottom:3px;padding-top:3px; ">STERN TESTING & CONSULTANCY PVT. LTD.</td>
								<td style="width:20%;text-align:center;font-weight:bold; " rowspan=5><img src="../images/mat_logo.png" style="height:40px;width:120px;background-blend-mode:multiply;"></td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">PLOT NO. G-2049, KADVANI FORGE,KISHAN GATE</td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">G.I.D.C.,KALAWAD ROAD,METODA,360021,RAJKOT</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:20px; ">
						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:20px;font-family : Calibri;">
							<tr style="">
								<td style="width:100%;padding-bottom:10px;padding-top:10px; text-align:center;font-weight:bold;border-right:1px solid;border-left:1px solid; " colspan="3"><span style=""> OBSERVATION AND CALCULATION SHEET FOR TEST ON SOIL</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="width:10%;font-weight:bold;text-align:center;border-top:1px solid; border-left:1px solid;">1</td>
								<td style="border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;border-top:1px solid; ">&nbsp;&nbsp; Job No.</td>
								<td style="border-left:1px solid;width:50%;border-top:1px solid;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">2</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Laboratory No</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">3</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of receipt of sample</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">4</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of starting test</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">5</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Probable date of completion</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">

							<tr>
								<td style="font-size: 14px;font-weight: bold;text-align: center;padding: 2px;text-transform: uppercase;border: 1px solid;">TRIAXIAL TEST As Per IS: 2720 (Part-15): 1965 Reaffirmed: 2021</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Load cell Capacity :-</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["t1"] ?></td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Load cell Least Count :-</td>
								<td style="padding: 2px;"><?php echo $row_select_pipe["t2"] ?> KN</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Type of Sample :-</td>
								<td style="padding: 2px;">Undisturbed / Remoulded</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Method of test :-</td>
								<td style="padding: 2px;">Unconsolidated Undrained / Consolidated Undrained / Consolidated Drained</td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
				</tr>

				<!-- table design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-top:2px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;" colspan="3">Specimen Details</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Trial-1</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Trial-2</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Trial-3</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;">Initial Length of Specimen</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; padding-left: 30px;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">cm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;" colspan="2">Area of Specimen</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">cm²</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;" colspan="2">Volume of Specimen</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">cm²</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;" colspan="2">Density of Soil</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">gm/cc</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;" colspan="2">Moisture Content</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">%</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;" colspan="2">Amount of Soil taken</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 1px solid;" colspan="2">Amount of Water taken</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">gm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<?php $cnt = 1; ?>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-top:1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;" colspan="5"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top:2px solid;" rowspan="4">Sr. No.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-top:2px solid;" colspan="4">Description</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;" rowspan="2">Time</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">Pressure - Kg/cm²</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">Pressure - Kg/cm²</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">Pressure - Kg/cm²</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">Load Cell Reading</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">Load Cell Reading</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">Load Cell Reading</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">min</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">KN</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">KN</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">KN</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">1</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">2</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.25</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">3</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">4</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.75</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">5</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">1.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">6</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">1.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">7</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">2.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">8</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">2.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">9</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">3.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">10</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">3.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">11</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">4.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">12</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">4.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">13</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">5.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">14</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">5.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">15</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">6.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">16</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">6.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">17</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">7.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">18</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">7.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">19</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">8.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">20</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">8.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">21</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">9.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">22</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">9.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">23</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">10.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">24</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">10.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">25</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">11.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">26</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">11.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">27</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">12.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">28</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">12.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">29</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">13.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">30</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">13.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">31</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">14.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">32</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">14.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">33</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">15.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<!-- footer design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border: 1px solid; ">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;width: 15%;border: 0px solid;">Checked By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding:5px;width: 12%;border: 0px solid;">Tested By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
							</tr>
							<tr>
								<td style="height: 35px;border: 1px solid;border-right: 1px solid; border-bottom:0px; border-top:1px solid;" colspan="4"></td>
							</tr>

						</table>
					</td>
				</tr>

			</table>
			<div class="pagebreak"></div>
			<br>
		<?php 
		if ($row_select_pipe['shear1'] != "" && $row_select_pipe['shear1'] != "0" && $row_select_pipe['shear1'] != null) { ?>

			<table align="center" width="100%" cellpadding="0" style="font-size:11px;height:auto;font-family : Calibri;border: 1px solid;padding: 0;border-collapse: collapse;">
				<!-- header design -->
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-top:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:30%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; DOC: STC/N/OS/001</td>
								<td style="width:20%;text-align:center;font-weight:bold; ">REV: 1</td>
								<td style="width:25%; font-weight:bold;">RD:- 01/01/2025</td>
								<td style="width:25%;font-weight:bold;">Page : 7</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:60%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; Prepared by: Technical Manager</td>
								<td style="width:40%;text-align:left;font-weight:bold; ">Approved by: Quality Manager</td>
							</tr>

						</table>

					</td>
				</tr>
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:80%;padding-left:150px; text-align:center;font-weight:bold;padding-bottom:3px;padding-top:3px; ">STERN TESTING & CONSULTANCY PVT. LTD.</td>
								<td style="width:20%;text-align:center;font-weight:bold; " rowspan=5><img src="../images/mat_logo.png" style="height:40px;width:120px;background-blend-mode:multiply;"></td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">PLOT NO. G-2049, KADVANI FORGE,KISHAN GATE</td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">G.I.D.C.,KALAWAD ROAD,METODA,360021,RAJKOT</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:20px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:20px;font-family : Calibri;">

							<tr style="">

								<td style="width:100%;padding-bottom:10px;padding-top:10px; text-align:center;font-weight:bold;border-right:1px solid;border-left:1px solid; " colspan="3"><span style=""> OBSERVATION AND CALCULATION SHEET FOR TEST ON SOIL</td>
							</tr>
							<?php
							if ($row_select_pipe['lab_no'] != "") {
								$cnt = 1;

							?>
								<tr style="font-size:10px;">

									<td style="width:10%;font-weight:bold;text-align:center;border-top:1px solid; border-left:1px solid;"><?php echo $cnt++; ?></td>
									<td style="border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;border-top:1px solid; ">&nbsp;&nbsp; Job No.</td>
									<td style="border-left:1px solid;width:50%;border-top:1px solid;border-right:1px solid; ">&nbsp;&nbsp; <?php echo $row_select_pipe['lab_no']; ?></td>
								</tr>
							<?php }
							if ($job_no != "") {
							?>
								<tr style="font-size:10px;">

									<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; "><?php echo $cnt++; ?></td>
									<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Laboratory No</td>
									<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; <?php echo $job_no; ?></td>
								</tr>
							<?php }
							//if($job_no!=""){
							?>
							<tr style="font-size:10px;">

								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; "><?php echo $cnt++; ?></td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of receipt of sample</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; <?php echo date('d-m-Y', strtotime($rec_sample_date)); ?></td>
							</tr>
							<tr style="font-size:10px;">

								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; "><?php echo $cnt++; ?></td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of starting test</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; <?php echo date('d-m-Y', strtotime($start_date)); ?></td>
							</tr>
							<tr style="font-size:10px;">

								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; "><?php echo $cnt++; ?></td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Probable date of completion</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; <?php echo date('d-m-Y', strtotime($end_date)); ?></td>
							</tr>
						</table>

					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">

							<tr>
								<td style="font-size: 14px;font-weight: bold;text-align: center;padding: 2px;text-transform: uppercase;border: 1px solid;">DIRECT SHEAR TEST As Per IS: 2720 (Part-13): 1986 Reaffirmed: 2021</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Load cell Capacity:-</td>
								<td style="text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["di1"] ?></td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Load cell Least Count:-</td>
								<td style="padding: 2px;"><?php echo $row_select_pipe["di2"] ?> KN</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Rate of Strain :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["rate1"] ?> mm/min</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Sample Type :-</td>
								<td style="text-align: left;padding: 2px;border: 0;">Remoulded / Undisturbed</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Test Method:-</td>
								<td style="text-align: left;padding: 2px;border: 0;">Unconsolidated Undrained / Consolidated Undrained / Consolidated Drained</td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="padding: 1px;border: 1px solid;" colspan="2"></td>
							</tr>
							<tr>
								<td style="font-size: 12px;font-weight: bold;text-align: center;padding: 2px;border-top: 0;width: 8%;" colspan="2">Soil Specimen Measurements</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;" colspan="2"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Density of Soil :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["dens1"] ?> gm/cc</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Moisture Content:-</td>
								<td style="padding: 2px;"><?php echo $row_select_pipe["moist1"] ?> %</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Mass of Soil taken :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["mass_1"] ?> gm</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Amount of water taken :-</td>
								<td style="padding: 2px;"><?php echo $row_select_pipe["amt_1"] ?> ml</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Area of Specimen :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"><?php echo $row_select_pipe["amt_2"] ?> cm²</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Volume of Specimen :-</td>
								<td style="padding: 2px;"><?php echo $row_select_pipe["amt_3"] ?> cm³</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-top:1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid; border-top:2px solid;" rowspan="4">Sr. No.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;border-top:2px solid;" colspan="4">Description</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2">Time</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Pressure - <?php echo $row_select_pipe["d_pres1"] ?> Kg/cm²</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Pressure - <?php echo $row_select_pipe["d_pres2"] ?> Kg/cm²</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Pressure - <?php echo $row_select_pipe["d_pres3"] ?> Kg/cm²</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Load Cell Reading</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Load Cell Reading</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Load Cell Reading</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">min</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">KN</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">KN</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">KN</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">1</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">2</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.25</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">3</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">4</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">0.75</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">5</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">1.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">6</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">1.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">7</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">2.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">8</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">2.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">9</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">3.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">10</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">3.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">11</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">4.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">12</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">4.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">13</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">5.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">14</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">5.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">15</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">6.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">16</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">6.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">17</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">7.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">18</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">7.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">19</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">8.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">20</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">8.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">21</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">9.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">22</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">9.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">23</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">10.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">24</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">10.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">25</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">11.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
									<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">26</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">11.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">27</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">12.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">28</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">12.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">29</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">13.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">30</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">13.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">31</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">14.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">32</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">14.50</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">33</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;">15.00</td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 0px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<!-- footer design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border: 1px solid; ">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;width: 15%;border: 0px solid;">Checked By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding:5px;width: 12%;border: 0px solid;">Tested By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
							</tr>
							<tr>
								<td style="height: 35px;border: 1px solid;border-right: 1px solid; border-bottom:0px; border-top:1px solid;" colspan="4"></td>
							</tr>

						</table>
					</td>
				</tr>

			</table>

			<div class="pagebreak"></div>
			<br>
		<?php }
		if ($row_select_pipe['loadpt3'] != "" && $row_select_pipe['loadpt3'] != "0" && $row_select_pipe['loadpt3'] != null) { ?>
			<table align="center" width="100%" cellpadding="0" style="font-size:11px;height:auto;font-family : Calibri;border: 1px solid;padding: 0;border-collapse: collapse;">
				<!-- header design -->
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-top:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:30%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; DOC: STC/N/OS/001</td>
								<td style="width:20%;text-align:center;font-weight:bold; ">REV: 1</td>
								<td style="width:25%; font-weight:bold;">RD:- 01/01/2025</td>
								<td style="width:25%;font-weight:bold;">Page : 7</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:60%;font-weight:bold;padding-bottom:2px;padding-top:2px; ">&nbsp;&nbsp; Prepared by: Technical Manager</td>
								<td style="width:40%;text-align:left;font-weight:bold; ">Approved by: Quality Manager</td>
							</tr>

						</table>

					</td>
				</tr>
				<tr>
					<td style="text-align:center;font-size:16px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:16px;font-family : Calibri;border-bottom:1px solid;border-right:1px solid;border-left:1px solid;">

							<tr style="">

								<td style="width:80%;padding-left:150px; text-align:center;font-weight:bold;padding-bottom:3px;padding-top:3px; ">STERN TESTING & CONSULTANCY PVT. LTD.</td>
								<td style="width:20%;text-align:center;font-weight:bold; " rowspan=5><img src="../images/mat_logo.png" style="height:40px;width:120px;background-blend-mode:multiply;"></td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">PLOT NO. G-2049, KADVANI FORGE,KISHAN GATE</td>
							</tr>
							<tr style="">
								<td style="width:80%; text-align:center;padding-left:150px;padding-bottom:3px;padding-top:3px; ">G.I.D.C.,KALAWAD ROAD,METODA,360021,RAJKOT</td>
							</tr>

						</table>

					</td>
				</tr>

				<tr>
					<td style="text-align:center;font-size:20px; ">

						<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:20px;font-family : Calibri;">
							<tr style="">
								<td style="width:100%;padding-bottom:10px;padding-top:10px; text-align:center;font-weight:bold;border-right:1px solid;border-left:1px solid; " colspan="3"><span style=""> OBSERVATION AND CALCULATION SHEET FOR TEST ON SOIL</td>
							</tr>
							<tr style="font-size:10px;">
								<td style="width:10%;font-weight:bold;text-align:center;border-top:1px solid; border-left:1px solid;">1</td>
								<td style="border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px;border-top:1px solid; ">&nbsp;&nbsp; Job No.</td>
								<td style="border-left:1px solid;width:50%;border-top:1px solid;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">2</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Laboratory No</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">3</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of receipt of sample</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">4</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Date of starting test</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
							<tr style="font-size:10px;">
								<td style="border-top:1px solid;width:10%;font-weight:bold;text-align:center;border-left:1px solid; ">5</td>
								<td style="border-top:1px solid;border-left:1px solid;width:40%;text-align:left;padding-bottom:3px;padding-top:3px; ">&nbsp;&nbsp; Probable date of completion</td>
								<td style="border-top:1px solid;border-left:1px solid;width:50%;border-right:1px solid; ">&nbsp;&nbsp; </td>
							</tr>
						</table>

					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;">

							<tr>
								<td style="font-size: 14px;font-weight: bold;text-align: center;padding: 2px;text-transform: uppercase;border: 1px solid;">CALIFORNIA BEARING RATlO TEST As Per IS : 2720 (Part-16) : 1987 Reaffirmed : 2021 , Clause No :- 5</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Type of Sample:-</td>
								<td style="text-align: left;padding: 2px;border: 0;">Undisturbed / Remoulded</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Test Method :-</td>
								<td style="padding: 2px;">Soaked / Unsoaked</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Proving Ring Constant :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"></td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Proving Ring Capacity :-</td>
								<td style="padding: 2px;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Dial Guage Least Count :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"></td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Dial Guage Capacity :-</td>
								<td style="padding: 2px;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Type of Compaction :-</td>
								<td style="text-align: left;padding: 2px;border: 0;">Static Compaction / Dynamic Compaction <br> Light Compaction / Heavy Compaction</td>
								<td></td>
								<td></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="padding: 1px;border: 1px solid;" colspan="2"></td>
							</tr>
							<tr>
								<td style="font-size: 12px;font-weight: bold;text-align: center;padding: 2px;border-top: 0;width: 8%;" colspan="2">Soil Specimen Measurements</td>
							</tr>
							<tr>
								<td style="padding: 1px;border: 1px solid;" colspan="2"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Maximum Dry density of Soil :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"> gm/cc</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Optimum Moisture Content :-</td>
								<td style="padding: 2px;"> %</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Mass of Soil taken :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"> gm</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Amount of water taken :-</td>
								<td style="padding: 2px;"> ml</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Surcharge Weight used :-</td>
								<td style="text-align: left;padding: 2px;border: 0;"> Kg</td>
								<td style="font-weight: bold;text-align: left;padding: 2px;border: 0;">Volume of Specimen :-</td>
								<td style="padding: 2px;"> cm³</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<?php $cnt = 1; ?>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-top:1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;" colspan="5"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2">Sr. No.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Penetration Depth</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Proving Ring Dial Guage Reading <br>(PRGDR)</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Load (PT)</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">mm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">mm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">kg</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">1</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.0</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">2</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">0.5</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">3</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">1.0</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">4</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">1.5</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">5</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">2.0</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">6</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">2.5</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">7</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">3.0</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">8</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">4.0</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">9</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">5.0</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">10</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">7.5</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">11</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">10.0</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">12</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">12.5</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
						</table>
					</td>
				</tr>

				<tr>
					<td>
						<table align="left" width="70%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-top:1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 10px;border: 1px solid;" colspan="5"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;" rowspan="2">Sr. No.</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Penetration Depth</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Load (PT)</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">Total Standard <br>Load (PS)</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">CBR Value <br>PT/PS x 100</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">mm</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">kg</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">kgf</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">%</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">1</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">2.5</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 3px;border: 1px solid;">2</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;">5.0</td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding: 2px;border: 1px solid;"></td>
							</tr>
						</table>
						<table align="right" width="20%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-top:1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">Conversion Factors</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">1Kg/cm² = 100 KPa</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">1KPa = 100 KN/m²</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 7px;border: 1px solid;">1MPa = 1N/mm²</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table align="right" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border-left: 1px solid;border-right: 1px solid; border-top:1px solid;">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px; border-right:0px; " colspan="3">Notes : (i) Air drying soil sample passing 19 mm sieve. If larger portion of sample is retained on 19 mm, replace it by an equal amount which passes 19 mm and is retained on 4.75mm.</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px; border-right:0px;">(ii) Table - 1 for Total Standard Load (PS)</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">Penetration</td>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">Unit Standard</td>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">Total Standard Load</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">Depth</td>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">Load</td>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">Load</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">mm</td>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">kg/cm²</td>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">kgf</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">2.5</td>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">70</td>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">1370</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">5.0</td>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">105</td>
								<td style="font-weight: bold;text-align: center;padding: 6px;border: 1px solid;">2055</td>
							</tr>
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 2px;" colspan="3">(iii) CBR Value at 2.5 mm Penetration will be greater than 5.0 mm for design Purpose. If CBR Value exceed at 5.0 mm penetration then test shall be repeated. If Identical result follow the CBR Value at 5.0 mm Penetration shall be take for design./td>
							</tr>
						</table>
					</td>
				</tr>


				<!-- footer design -->
				<tr>
					<td>
						<table align="center" width="100%" style="font-size:11px;height:auto;font-family : Calibri;border-collapse: collapse;border: 1px solid; ">
							<tr>
								<td style="font-weight: bold;text-align: left;padding: 5px;width: 15%;border: 0px solid;">Checked By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
								<td style="font-weight: bold;text-align: center;padding:5px;width: 12%;border: 0px solid;">Tested By :-</td>
								<td style="padding: 5px;border: 0px solid;"></td>
							</tr>
							<tr>
								<td style="height: 35px;border: 1px solid;border-right: 1px solid; border-bottom:0px; border-top:1px solid;" colspan="4"></td>
							</tr>

						</table>
					</td>
				</tr>

			</table>

		<?php  } ?>

	</page>

</body>

</html>


<script type="text/javascript">
	// window.onload = function() {
	// 	setTimeout(function() {

	// 			window.print();
	// 		},
	// 		1000);

	// }
</script>