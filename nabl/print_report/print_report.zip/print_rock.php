<?php 
session_start();
include("../connection.php");
include("function_calling.php");
error_reporting(1);?>
<style>
@page { margin: 0 40px; }
.pagebreak { page-break-before: always; }
page[size="A4"] {
  width: 21cm;
  height: 29.7cm;  
} 

@media print
{    
    #header_hide_show
    {
        display: none !important;
		
    }
}

</style>
<style>
.tdclass{
    border: 1px solid black;
    font-size:12px;
	 font-family : Calibri;
	
}
.test {
    border-collapse: collapse;
 font-size:12px;
	 font-family : Calibri;
}
	.tdclass1{
    
    font-size:12px;
	 font-family : Calibri;
}
div.vertical-sentence{
  -ms-writing-mode: tb-rl; /* for IE */
  -webkit-writing-mode: vertical-rl; /* for Webkit */
  writing-mode: vertical-rl;
  
}
.rotate-characters-back-to-horizontal{ 
  -webkit-text-orientation: upright;  /* for Webkit */
  text-orientation: upright; 
}



</style>
<html>
	<body>
			<?php
			function round_up($number, $precision = 0)
				{
					$fig = (int) str_pad('1', $precision, '0');
					return (ceil($number * $fig) / $fig);
				}
			$job_no = $_GET['job_no'];
			$lab_no = $_GET['lab_no'];
			$avg_den = $_GET['avg_den'];
			$report_no = $_GET['report_no'];
			$trf_no = $_GET['trf_no'];
			$select_tiles_query = "select * from rock WHERE `lab_no`='$lab_no' AND `report_no`='$report_no' AND `job_no`='$job_no' and `is_deleted`='0' ORDER BY `id`";
			$result_tiles_select = mysqli_query($conn, $select_tiles_query);
			$row_select_pipe = mysqli_fetch_array($result_tiles_select);
			$no_of_rows=mysqli_num_rows($result_tiles_select);
			 $page_cont = round_up($no_of_rows/7);
			
			$ans = mysqli_fetch_array($result_tiles_select);
				
				
			 $select_query = "select * from job WHERE `trf_no`='$trf_no' AND `jobisdeleted`='0'";
			$result_select = mysqli_query($conn,$select_query);				
			
			$row_select = mysqli_fetch_array($result_select);
			$clientname= $row_select['clientname'];
			
			$client_address= $row_select['clientaddress'];
			$r_name= $row_select['refno'];
			$r_date= $row_select['date'];
			$agreement_no= $row_select['agreement_no'];
			
			$rec_sample_date= $row_select['sample_rec_date'];	
			$cons= $row_select['condition_of_sample_receved'];			
			if($cons == 0)
			{
				$con_sample = "Sealed";
			}
			else
			{
				$con_sample = "Unsealed";
			}
			$name_of_work= strip_tags(html_entity_decode($row_select['nameofwork']),"<strong><em>");						

			$select_query1 = "select * from agency_master WHERE `agency_id`='$row_select[agency]' AND `isdeleted`='0'";
			$result_select1 = mysqli_query($conn, $select_query1);

			if (mysqli_num_rows($result_select1) > 0) {
				$row_select1 = mysqli_fetch_assoc($result_select1);
				$agency_name= $row_select1['agency_name'];
			}
			
			
			if($row_select["agency_name"] !="")
			{
				$agency_name= $row_select['agency_name'];
			}
			
			$select_query2  = "select * from job_for_engineer WHERE `lab_no`='$lab_no' AND `trf_no`='$trf_no' AND `job_no`='$job_no' AND `isdeleted`='0'";
			$result_select2 = mysqli_query($conn, $select_query2);

			if (mysqli_num_rows($result_select2) > 0) {
				$row_select2 = mysqli_fetch_assoc($result_select2);
				$start_date= $row_select2['start_date'];
				$end_date= $row_select2['end_date'];
				$issue_date= $row_select2['issue_date'];								
				$select_query3 = "select * from material WHERE `id`='$row_select2[material_id]' AND `mt_isdeleted`='0'"; 
				$result_select3 = mysqli_query($conn, $select_query3);

				if (mysqli_num_rows($result_select3) > 0) {
					$row_select3 = mysqli_fetch_assoc($result_select3);
					$mt_name= $row_select3['mt_name'];
					include_once 'sample_id.php';
				}
				
			}
			
			 $select_query4 = "select * from span_material_assign WHERE `lab_no`='$lab_no' AND `trf_no`='$trf_no' AND `job_number`='$job_no' AND `isdeleted`='0' ";
				$result_select4 = mysqli_query($conn, $select_query4);

				if (mysqli_num_rows($result_select4) > 0) {
					$row_select4 = mysqli_fetch_assoc($result_select4);
					$cc_grade= $row_select4['cc_grade'];
					$cc_set_of_cube= $row_select4['cc_set_of_cube'];
					$cc_no_of_cube= $row_select4['cc_no_of_cube'];
					$cc_identification_mark= $row_select4['cc_identification_mark'];
					$day_remark= $row_select4['day_remark'];
					$casting_date= $row_select4['casting_date'];
					$material_location= $row_select4['material_location'];
				}
				
			$flag=0;
			$a = 1;
			$down=0;
			$up = 7;
			for($a=1;$a<=$page_cont;$a++)
			{

		?>
		
		
<?php //if (($row_select_pipe['sp_specific_gravity'] != "" && $row_select_pipe['sp_specific_gravity'] != "0" && $row_select_pipe['sp_specific_gravity'] != null) || ($row_select_pipe['sp_sg_avg_2'] != "" && $row_select_pipe['sp_sg_avg_2'] != "0" && $row_select_pipe['sp_sg_avg_2'] != null) || ($row_select_pipe['sp_sg_avg_3'] != "" && $row_select_pipe['sp_sg_avg_3'] != "0" && $row_select_pipe['sp_sg_avg_3'] != null) || ($row_select_pipe['wc_1'] != "" && $row_select_pipe['wc_1'] != "0" && $row_select_pipe['wc_1'] != null) || ($row_select_pipe['wc_2'] != "" && $row_select_pipe['wc_2'] != "0" && $row_select_pipe['wc_2'] != null) || ($row_select_pipe['wc_3'] != "" && $row_select_pipe['wc_3'] != "0" && $row_select_pipe['wc_3'] != null) || ($row_select_pipe['sp_water_abr'] != "" && $row_select_pipe['sp_water_abr'] != "0" && $row_select_pipe['sp_water_abr'] != null) || ($row_select_pipe['sp_wa_avg_2'] != "" && $row_select_pipe['sp_wa_avg_2'] != "0" && $row_select_pipe['sp_wa_avg_2'] != null) || ($row_select_pipe['sp_wa_avg_3'] != "" && $row_select_pipe['sp_wa_avg_3'] != "0" && $row_select_pipe['sp_wa_avg_3'] != null) || ($row_select_pipe['por_1'] != "" && $row_select_pipe['por_1'] != "0" && $row_select_pipe['por_1'] != null) || ($row_select_pipe['por_2'] != "" && $row_select_pipe['por_2'] != "0" && $row_select_pipe['por_2'] != null) || ($row_select_pipe['por_3'] != "" && $row_select_pipe['por_3'] != "0" && $row_select_pipe['por_3'] != null) || ($row_select_pipe['pd_1'] != "" && $row_select_pipe['pd_1'] != "0" && $row_select_pipe['pd_1'] != null) || ($row_select_pipe['pd_2'] != "" && $row_select_pipe['pd_2'] != "0" && $row_select_pipe['pd_2'] != null) || ($row_select_pipe['pd_3'] != "" && $row_select_pipe['pd_3'] != "0" && $row_select_pipe['pd_3'] != null) || ($row_select_pipe['com_99'] != "" && $row_select_pipe['com_99'] != "0" && $row_select_pipe['com_99'] != null) || ($row_select_pipe['com_100'] != "" && $row_select_pipe['com_100'] != "0" && $row_select_pipe['com_100'] != null) || ($row_select_pipe['com_101'] != "" && $row_select_pipe['com_101'] != "0" && $row_select_pipe['com_101'] != null) || ($row_select_pipe['com_102'] != "" && $row_select_pipe['com_102'] != "0" && $row_select_pipe['com_102'] != null) || ($row_select_pipe['com_103'] != "" && $row_select_pipe['com_103'] != "0" && $row_select_pipe['com_103'] != null) || ($row_select_pipe['com_104'] != "" && $row_select_pipe['com_104'] != "0" && $row_select_pipe['com_104'] != null) || ($row_select_pipe['com_105'] != "" && $row_select_pipe['com_105'] != "0" && $row_select_pipe['com_105'] != null) || ($row_select_pipe['com_106'] != "" && $row_select_pipe['com_106'] != "0" && $row_select_pipe['com_106'] != null) || ($row_select_pipe['com_107'] != "" && $row_select_pipe['com_107'] != "0" && $row_select_pipe['com_107'] != null) || ($row_select_pipe['com_108'] != "" && $row_select_pipe['com_108'] != "0" && $row_select_pipe['com_108'] != null)) { ?>	
			<br>
	<br>
	<br>
	<br>
	<br>
	<br>

	<page size="A4">
	<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;margin-top:60px;">
		<tr>
			<td>
				<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;font-weight: bold;border: 1px solid;">
						<tr>
							<td style="padding: 0 2px;text-align: left;">&nbsp;<?php echo $report_no; ?></td>
							
							<td style="padding: 0 2px;text-align: left;">&nbsp;<?php if(strlen($_GET['ulr'])>15){echo $_GET['ulr'];}?></td>
							<td style="padding: 0 2px;text-align: right;">&nbsp;Page 1 of 1</td>
						</tr>
						<tr>
							<td style="width: 80%;padding: 0 2px;text-align: left;border-top:1px solid;" colspan="2">&nbsp;Prepared by : Technical Manager</td>
							<td style="padding: 0 2px;width:20%;text-align: right;border-top:1px solid;">&nbsp;Approved by : Quality Manager</td>
						</tr>
						
				</table>
				<br>
				<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;font-weight: bold;">
						<tr>
							<td style="width: 54.5%;padding: 0 2px;text-align: right;">&nbsp;Group:- Building Materials</td>
							<td style="padding: 0 2px;width:45%;text-align: right;">&nbsp;Date:<?php echo date('d/m/Y', strtotime($issue_date));?></td>
						</tr>
						
				</table>
				<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;font-weight: bold;">
						<tr>
							<td style="width: 50%;padding: 0 2px;text-align: center;">&nbsp;Discipline:- Mechanical</td>
						</tr>
						
				</table>
				<br>
				<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;font-weight: bold;border: 1px solid;">
					<tr>
						<td style="text-transform: uppercase;font-weight: bold;text-decoration: underline;text-align: center;font-size: 15px;padding: 2px 0;"  colspan="4">TITLE : TEST REPORT OF ROCK</td>
					</tr>
				</table>
				<br>	
				<br>	
				<table align="left" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;border: 1px solid;border-top: 1px solid;border-bottom: 0;">
						<tr>
							<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;font-weight: bold;">&nbsp;Name of Work :-</td>
							<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="6">&nbsp;<?php echo $name_of_work;?></td>
						</tr>
						<tr>
							<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;font-weight: bold;">&nbsp;Name of Client :-</td>
							<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="4">&nbsp;<?php echo $clientname;?></td>
							<td style="padding: 0 2px;text-align: left;font-weight: bold;">&nbsp;Location</td>
							<td style="padding:2px;text-align: left;"><b>&nbsp; : &nbsp;</b><?php if ($material_location == 1) {echo "In Laboratory";} else {echo "In Field";} ?></td>
						</tr>				
						<tr>
							<td style="border-bottom: 0px solid;padding: 0 2px;text-align: left;font-weight: bold;">&nbsp;Date of Receipt Sample :-</td>
							<td style="border-bottom: 0px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="4">&nbsp;<?php echo date('d/m/Y', strtotime($rec_sample_date));?></td>
							<td style="text-align: left;border-left: 1px solid;font-weight: bold;" rowspan="2">&nbsp;Sender's Reference</td>
							<td style="padding: 0 2px;text-align: left;border-left: 1px solid;">&nbsp;<?php echo $r_name; ?>&nbsp;&nbsp;<?php
																									if ($row_select["date"] != "" && $row_select["date"] != "null" && $row_select["date"] != "0000-00-00"  && $row_select["date"] != "1970-01-01" ) {
																									?>Date: <?php echo date('d/m/Y', strtotime($row_select["date"]));
																									} else {
																									}
							?></td>
						</tr>
						
						<tr>
							<td style="border-top: 1px solid;padding: 0 2px;text-align: left;font-weight: bold;">&nbsp;Date of Test Performed :-</td>
							<td style="border-top: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: center;">&nbsp;From</td>
							<td style="border-top: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: center;">&nbsp;<?php echo date('d/m/Y', strtotime($rec_sample_date)); ?></td>
							<td style="border-top: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: center;">&nbsp;To</td>
							<td style="border-top: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: center;">&nbsp;<?php echo date('d/m/Y', strtotime($end_date)); ?></td>
							<td style="border-top: 1px solid;padding: 0 2px;text-align: left;border-left: 1px solid;">&nbsp;Date :- <?php echo date('d/m/Y', strtotime($rec_sample_date));?></td>
						</tr>
						<tr>
							<td style="border-top: 1px solid;padding: 0 2px;text-align: left;font-weight: bold;">&nbsp;Enviromental Condition :-</td>
							<td style="border-top: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;font-weight:bold;" colspan="2">&nbsp;Temperature :-</td>
							<td style="border-top: 1px solid;padding: 0 2px;text-align: center;border-left: 1px solid;" colspan="2">&nbsp;27˚± 2 ˚c</td>
							<td style="border-top: 1px solid;padding: 0 2px;text-align: left;border-left: 1px solid;font-weight: bold;">&nbsp;Grade</td>
							<td style="border-top: 1px solid;padding: 0 2px;text-align: left;border-left: 1px solid;">&nbsp;-</td>
						</tr>
						<tr>
							<td style="border-top: 1px solid;padding: 0 2px;text-align: left;font-weight: bold;">&nbsp;Sampling Method :-</td>
							<td style="border-top: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="4">&nbsp;Sample Collected by the Supplier</td>
							<td style="border-top: 1px solid;padding: 0 2px;text-align: left;border-left: 1px solid;font-weight: bold;">&nbsp;Job No. :- </td>
							<td style="border-top: 1px solid;padding: 0 2px;text-align: left;border-left: 1px solid;">&nbsp;<?php echo $job_no;?></td>
						</tr>
						<tr>
							<td style="border-bottom: 1px solid;border-top: 1px solid;padding: 0 2px;text-align: left;font-weight: bold;">&nbsp;Identification Mark :-</td>
							<td style="border-bottom: 1px solid;border-top: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="4">&nbsp;<?php echo $cc_identification_mark; ?></td>
							<td style="border-top: 1px solid;border-bottom: 1px solid;padding: 0 2px;text-align: left;border-left: 1px solid;font-weight: bold;">&nbsp;Lab No. :- </td>
							<td style="border-top: 1px solid;border-bottom: 1px solid;padding: 0 2px;text-align: left;border-left: 1px solid;">&nbsp;<?php echo $lab_no;?></td>
						</tr>
						
				</table>
				<!--<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;font-weight: bold;padding-top:20px;padding-bottom:20px;">
						<tr>
							<td style="width: 50%;padding: 0 2px;text-align: left;font-size:15px;">&nbsp;Dimensions Tolerances</td>
						</tr>
						
				</table>-->
				<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri; border-right:1px solid;border-bottom: 1px solid;padding-top:20px;">
			<tr style="">
                <td style="border-top:1px solid;font-size:11px;border-left: 1px solid black;text-align:center;font-weight:bold;padding:3px 0px;width:9%"> Sr no.</td>
                <td style="border-top:1px solid;font-size:11px;border-left: 1px solid black;text-align:center;font-weight:bold;padding:3px 0px;width:9%"> Test</td>
                <td style="border-top:1px solid;font-size:11px;border-left: 1px solid black;text-align:center;font-weight:bold;padding:3px 0px;width:9%">Result</td>                            
                <td style="border-top:1px solid;font-size:11px;border-left: 1px solid black;text-align:center;font-weight:bold;padding:3px 0px;width:9%">Test Method</td> 
                <td style="border-top:1px solid;font-size:11px;border-left: 1px solid black;text-align:center;font-weight:bold;padding:3px 0px;width:9%">Requirement</td> 
            </tr>
			<?php if ($row_select_pipe['sp_specific_gravity'] != "" && $row_select_pipe['sp_specific_gravity'] != null && $row_select_pipe['sp_specific_gravity'] != "0") { 
			?>
			<tr style="">
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;"><?php echo $cnt++; ?></td>
                <td style="font-size:11px;text-align:left;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">&nbsp;Specific Gravity (gm/cc)</td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;"><?php echo $row_select_pipe['sp_specific_gravity']?></td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;" rowspan="2">IS 1124 : 1974</td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">-</td>
            </tr>
			<?php 
			}
			if ($row_select_pipe['sp_water_abr'] != "" && $row_select_pipe['sp_water_abr'] != null && $row_select_pipe['sp_water_abr'] != "0") { 
			?>
			<tr style="">
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;"><?php echo $cnt++; ?></td>
                <td style="font-size:11px;text-align:left;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">&nbsp;Water Absorption (%)</td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;"><?php echo $row_select_pipe['sp_water_abr']?></td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">-</td>
            </tr>
			<?php 
			}
			//if ($row_select_pipe['com_99'] != "" && $row_select_pipe['com_99'] != null && $row_select_pipe['com_99'] != "0") { 
			?>
			<tr style="">
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;"><?php echo $cnt++; ?></td>
                <td style="font-size:11px;text-align:left;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">&nbsp;Compressive Strength (kg/cm<sup>2</sup>)</td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;"><?php echo $row_select_pipe['com_99']?></td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">IS 1121 : 1974</td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">-</td>
            </tr>
			<?php 
			//}
			//if ($row_select_pipe['dim_height'] != "" && $row_select_pipe['dim_height'] != null && $row_select_pipe['dim_height'] != "0") { 
			?>
			<tr style="">
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;"><?php echo $cnt++; ?></td>
                <td style="font-size:11px;text-align:left;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">&nbsp;Acid Test</td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;"><?php echo $row_select_pipe['dim_height']?></td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">-</td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">-</td>
            </tr>
			<?php 
			//}
			//if ($row_select_pipe['dim_height'] != "" && $row_select_pipe['dim_height'] != null && $row_select_pipe['dim_height'] != "0") { 
			?>
			<tr style="">
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;"><?php echo $cnt++; ?></td>
                <td style="font-size:11px;text-align:left;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">&nbsp;Smith Test</td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;"><?php echo $row_select_pipe['dim_height']?></td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">-</td>
                <td style="font-size:11px;text-align:center;border:1px solid black;border-left:1px solid black;padding:3px 0px;border-right:0px;border-bottom:0px;">-</td>
            </tr>
			<?php// }?>
	</table>
	<br>
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;">
			
			<tr>
				<td>
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;">
						
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;">NOTES :-</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;padding-left:60px;" colspan="2">1) Test results related to sample collected by Customer.</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;padding-left:60px;" colspan="2">2) Results/Reports are issued with the specific understanding that Stern Testing & Consultancy Pvt. Ltd. will not, in any case, be involved in action following the interpretation of test results.</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;padding-left:60px;" colspan="2">3) The reports/results are not supposed to be used for Publicity.</td>
						</tr>
						
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;width:70%;padding-top:50px;"></td>
							<td style="padding: 1px 2px;font-weight: bold;width:30%;">Stern Testing & Consultancy Pvt. Ltd.</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;width:70%;padding-top:80px;"></td>
							<td style="padding: 1px 2px;font-weight: bold;width:30%;padding-left:5%;">Authorized Signature</td>
						</tr>
						
					</table>
				</td>
			</tr>

		</table>
			</td>
		</tr>
		</table>
	<!--<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;margin-top:60px;border: 1px solid;border: bottom: 0;">
		<tr>
			<td>
				<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;font-weight: bold;border: 1px solid;">
					<tr>
						<td style="text-transform: uppercase;font-weight: bold;text-decoration: underline;text-align: center;font-size: 13px;padding: 2px 0;border-bottom: 1px solid;"  colspan="4">Test Report - ROCK</td>
					</tr>
					<tr>
						<td style="border-bottom: 1px solid;padding: 1px 0;" colspan="4"></td>
					</tr>
					<tr>
						<td style="width: 14%;padding: 0 2px;">&nbsp;Sample ID No :-</td>
						<td style="width: 62.4%;padding: 0 2px;border-left: 1px solid;">&nbsp;<?php echo $sample_id; ?></td>
						<td style="text-align: left;border-left: 1px solid;">&nbsp;Report Date :-</td>
						<td style="padding: 0 2px;text-align: left;border-left: 1px solid;">&nbsp;<?php echo date('d/m/Y', strtotime($issue_date)); ?></td>
					</tr>
				</table>
				<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;font-weight: bold;border: 1px solid;border-top: 0;border-bottom: 0;">
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;">&nbsp;Report No :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;">&nbsp;<?php echo $report_no; ?></td>
						<td style="border-bottom: 1px solid;text-align: left;border-left: 1px solid;">&nbsp;ULR No :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;border-left: 1px solid;">&nbsp;<?php echo $_GET['ulr']; ?></td>
					</tr>
					<!--STATIC AMENDMENT NO AND DATE->
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;">&nbsp;Amendment No :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;">&nbsp;--</td>
						<td style="border-bottom: 1px solid;text-align: left;border-left: 1px solid;">&nbsp;Group :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;border-left: 1px solid;">&nbsp;Building Materials</td>
					</tr>
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;">&nbsp;Amendment Date :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;">&nbsp; <?php echo date('d/m/Y', strtotime($row_select_pipe["amend_date"])); ?></td>
						<td style="border-bottom: 1px solid;text-align: left;border-left: 1px solid;">&nbsp;Discipline :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;border-left: 1px solid;">&nbsp;Mechanical</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<!-- header part ->
			<td>
				<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;font-weight: bold;border: 1px solid;border-top: 0;border-bottom: 0;">
					<tr>
						<td style="border-bottom: 1px solid;padding: 1px 0;" colspan="4"></td>
					</tr>
					<?php
						if ($clientname != "") {
						?>
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;width: 24.9%;">&nbsp;Customer Name & Address :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="3">&nbsp;<?php echo $clientname; ?></td>
					</tr>
					<?php
						}
						if ($agency_name != "") {
						?>
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;">&nbsp;Agency Name :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="3">&nbsp;<?php echo $agency_name; ?></td>
					</tr>
					<?php } 
					if ($row_select['tpi_name'] != "") {
						?>
							
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;">&nbsp;Consultants :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="3">&nbsp;<?php echo $row_select['tpi_name']; ?></td>
					</tr>
					<?php
						 }
						if ($agreement_no != "") {
						?>
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;">&nbsp;Agreement No :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="3">&nbsp;<?php echo $agreement_no; ?></td>
					</tr>
					<?php
						}
						if ($name_of_work != "") {
						?>
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;">&nbsp;Project Name :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="3">&nbsp;<?php echo $name_of_work; ?></td>
					</tr>
					<?php } ?>
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;">&nbsp;Letter Reference No :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="3">&nbsp;<?php echo $r_name; ?>&nbsp;&nbsp;<?php
																									if ($row_select["date"] != "" && $row_select["date"] != "null" && $row_select["date"] != "0000-00-00"  && $row_select["date"] != "1970-01-01" ) {
																									?>Date: <?php echo date('d/m/Y', strtotime($row_select["date"]));
																									} else {
																									}
							?>
</td>
					</tr>
					
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;">&nbsp;Received Material :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="3">&nbsp;<?php echo $mt_name; ?> 	</td>
					</tr>
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;">&nbsp;Received Sample Date :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="3">&nbsp;<?php echo date('d/m/Y', strtotime($rec_sample_date));?></td>
					</tr>
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;">&nbsp;Received Sample Condition :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="3">&nbsp;<?php echo $con_sample; ?></td>
					</tr>
					<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;">&nbsp;Sample Testing Date :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;">&nbsp;<?php echo date('d/m/Y', strtotime($start_date)); ?></td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: center;width:4%;">&nbsp;To</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;">&nbsp;<?php echo date('d/m/Y', strtotime($end_date)); ?></td>
					</tr>
					<!--<tr>
						<td style="border-bottom: 1px solid;padding: 0 2px;text-align: left;">&nbsp;Sample Source :-</td>
						<td style="border-bottom: 1px solid;padding: 0 2px;border-left: 1px solid;text-align: left;" colspan="3">&nbsp;<?php echo $source; ?></td>
					</tr>-->
					
					<tr>
						<td style="padding: 1px 0;border: bottom: 0;" colspan="4"></td>
					</tr>
				</table>
				
			</td>
		</tr>
	</table>
	


        <!-- <table align="center" width="92%"  cellspacing="0" cellpadding="0" style="font-size:13px;font-family : Calibri;border:1px solid black;margin-left:35px; ">
	 		
			<tr style="border: 1px solid black;height:20px;"> 
				<td width="30%" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php if($row_select_pipe['ulr'] != "" && $row_select_pipe['ulr'] != "0" && $row_select_pipe['ulr'] != null){
					echo "<b>ULR:</b> ".$row_select_pipe['ulr'];}?></td>
				
				<td width="65%" style="text-align:right; margin:15px;border-bottom: 1px solid black;  "><?php if($report_no != "" && $report_no != "0" && $report_no != null){
					echo " ".$report_no;}?><b>&nbsp;/&nbsp;Date:</b> <?php echo date('d-m-Y', strtotime($issue_date));?>&nbsp;&nbsp;&nbsp;</td>
			</tr>

			<tr style="border: 1px solid black;height:20px;">
				<td style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp; <b> Report Submited To </b></td>
				<td colspan="2" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php $select_queryc = "select * from city WHERE `id`='$row_select[client_city]'"; 
						$result_selectc = mysqli_query($conn, $select_queryc);

							if (mysqli_num_rows($result_selectc) > 0) {
								$row_selectc = mysqli_fetch_assoc($result_selectc);
								$ct_nm= $row_selectc['city_name'];
							}
								echo $clientname." ".$row_select['clientaddress']." ".$ct_nm;?> </td>
			</tr>

			<tr style="border: 1px solid black;height:Auto;height:20px;">
				<td style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp;<b> Name of <span id="put_details"></span><select style="font-weight:bold;border:0px;font-size:11px;" onchange="put_details()" id="details_of_sample"><option>Work</option><option>Project</option></select></b></td>
				<td colspan="2" style="border-bottom: 1px solid black;padding-left:10px ">&nbsp;&nbsp;<?php echo $name_of_work;?> </td>
			</tr>

			<tr style="border: 1px solid black;height:Auto;height:20px;">
				<td style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp;<b> Detailes of Sample</b></td>
				<td colspan="3" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php echo $mt_name;?> </td>
			</tr>

			<tr style="border: 1px solid black;height:20px;">
				<td style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp;<b> Reference Letter No.</b></td>
				<td colspan="2" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php 
				echo $r_name." Date:".date('d/m/Y', strtotime($row_select2["letter_date"])); 
				
				?> </td>
			</tr>

			<tr style="border: 1px solid black;height:20px;">
				<td style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp;<b> Date of Receipt of Sample</b></td>
				<td colspan="3" style="border-bottom: 1px solid black; ">&nbsp;&nbsp;  <?php echo date('d/m/Y', strtotime($rec_sample_date)); ?> </td>
			</tr>

			<tr style="border: 1px solid black;height:20px;">
				<td style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp;<b> Condition of Sample during receipt</b></td>
				<td colspan="3" style="border-bottom: 1px solid black; ">&nbsp;&nbsp;  <?php if($cons=="1"){ echo "Sealed";}elseif($cons=="2"){ echo "Unsealed";}elseif($cons=="3"){ echo "Good";}elseif($cons=="4"){ echo "Poor";}else{ echo "Sealed";} ?> </td>
			</tr>

			<tr style="border: 1px solid black;height:20px;">
				<td style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp; <b> Name of Agency</b></td>
				<td colspan="3" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php $select_queryc1 = "select * from city WHERE `id`='$row_select[agency_city]'"; 
															$result_selectc1 = mysqli_query($conn, $select_queryc1);

															if (mysqli_num_rows($result_selectc1) > 0) {
																$row_selectc1 = mysqli_fetch_assoc($result_selectc1);
																$ct_nm1= $row_selectc1['city_name'];
															}
															echo $agency_name." ".$ct_nm1;?> </td>
			</tr>

			<?php if($agreement_no != ""){?>
			<tr style="border: 1px solid black;height:20px;">
				<td style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp;<b> Aggrement No.</b></td>
				<td colspan="3" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php echo $agreement_no; ?></td>
			</tr>
			<?php } ?>

			<tr style="border: 1px solid black;height:20px;">
				<td style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp;<b> Job No.</b></td>
				<td colspan="2" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php echo $job_no;?></td>
			</tr>

			<tr style="border: 1px solid black;height:20px;">
				<td style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp;<b> Lab No.</b></td>
				<td colspan="2" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php 
				
		
				echo $lab_no;
				?></td>
			</tr>

			<?php 
				$first_tag = $row_select['first_tag'];
				$second_tag = $row_select['second_tag'];
				$third_tag = $row_select['third_tag'];
				$fourth_tag = $row_select['fourth_tag'];
				
				$first_txt = $row_select['first_txt'];
				$second_txt = $row_select['second_txt'];
				$third_txt = $row_select['third_txt'];
				$fourth_txt = $row_select['fourth_txt'];
				if($first_tag != null && $first_tag != ""){?>
				<tr>
					<td style="border-bottom: 1px solid black;border-right: 1px solid black;height:20px;">&nbsp;&nbsp;<b><?php echo $first_tag;?></b></td>
					<td colspan="3" style="border-bottom: 1px solid black;">&nbsp;&nbsp;<?php echo $first_txt;?></td>				
				</tr>
				<?php }if($second_tag != null && $second_tag != ""){?>
				<tr>
					<td style="border-bottom: 1px solid black;border-right: 1px solid black;height:20px;">&nbsp;&nbsp;<b><?php echo $second_tag;?></b></td>
					<td colspan="3" style="border-bottom: 1px solid black;">&nbsp;&nbsp;<?php echo $second_txt;?></td>				
				</tr>
				<?php }if($third_tag != null && $third_tag != ""){?>
				<tr>
					<td style="border-bottom: 1px solid black;border-right: 1px solid black;height:20px;">&nbsp;&nbsp;<b><?php echo $third_tag;?></b></td>
					<td colspan="3" style="border-bottom: 1px solid black;">&nbsp;&nbsp;<?php echo $third_txt;?></td>				
				</tr>
				<?php }if($fourth_tag != null && $fourth_tag != ""){?>
				<tr >
					<td style="border-bottom: 1px solid black;border-right: 1px solid black;height:20px;">&nbsp;&nbsp;<b><?php echo $fourth_tag;?></b></td>
					<td colspan="3" style="border-bottom: 1px solid black;">&nbsp;&nbsp;<?php echo $fourth_txt;?></td>				
				</tr>
				<?php }?>
				
				
				
				<tr style="border: 1px solid black;height:20px;">
				<td width="35%" style="border-bottom: 1px solid black;border-right: 1px solid black; ">&nbsp;&nbsp;<b> Starting Date of Test</b></td>
				<td width="20%" style="border-bottom: 1px solid black; border-right: 1px solid black;">&nbsp;&nbsp; <?php echo date("d/m/Y", strtotime($start_date)); ?></td>
				</TR>
				<tr style="border: 1px solid black;height:20px;">
				<td width="25%" style="border-bottom: 1px solid black;border-right: 1px solid black; text-align:LEFT;">&nbsp;&nbsp;<b> Completion Date of Test &nbsp;</b></td>
				<td width="20%" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php echo date("d/m/Y", strtotime($end_date));?></td>
				</tr>
				<?php if($row_select_pipe['bh_no'] != null && $row_select_pipe['bh_no'] != "" && $row_select_pipe['bh_no']!="0"){?>
				<tr style="border: 1px solid black;height:20px;">
				<td width="25%" style="border-bottom: 1px solid black;border-right: 1px solid black; text-align:LEFT;">&nbsp;&nbsp;<b> Bor Hall No. &nbsp;</b></td>
				<td width="20%" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php echo $row_select_pipe['bh_no'];?></td>
				</tr>
				<?php } if($row_select_pipe['rock_depth'] != null && $row_select_pipe['rock_depth'] != "" && $row_select_pipe['rock_depth']!="0"){?>
				<tr style="border: 1px solid black;height:20px;">
				<td width="25%" style="border-bottom: 1px solid black;border-right: 1px solid black; text-align:LEFT;">&nbsp;&nbsp;<b>Depth of Bor Hall &nbsp;</b></td>
				<td width="20%" style="border-bottom: 1px solid black; ">&nbsp;&nbsp; <?php echo $row_select_pipe['rock_depth']." mt.";?></td>
				</tr>
				<?php }?>
		</table> -->
		
		
        <!--OTHER START->
		    <table align="center" width="100%"  cellspacing="0" cellpadding="0" style="">
				<td>
					<table align="left" width="100%"  class="test" style="font-size:11px;font-family : Calibri;border-bottom:1px solid;border-right:2px solid;border-left:2px solid;" >
						<tr>
							<td  style="border-top:0px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;">Depth / Bor Hall No.</td>
							<td  style="border-top:0px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;">Particulars</td>
							
							<?php if (($row_select_pipe['sp_specific_gravity'] != "" && $row_select_pipe['sp_specific_gravity'] != "0" && $row_select_pipe['sp_specific_gravity'] != null) || ($row_select_pipe['sp_sg_avg_2'] != "" && $row_select_pipe['sp_sg_avg_2'] != "0" && $row_select_pipe['sp_sg_avg_2'] != null) || ($row_select_pipe['sp_sg_avg_3'] != "" && $row_select_pipe['sp_sg_avg_3'] != "0" && $row_select_pipe['sp_sg_avg_3'] != null)) { ?>
							
							<td  style="border-top:0px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;">Specific gravity</td>
							
							<?php } if (($row_select_pipe['wc_1'] != "" && $row_select_pipe['wc_1'] != "0" && $row_select_pipe['wc_1'] != null) || ($row_select_pipe['wc_2'] != "" && $row_select_pipe['wc_2'] != "0" && $row_select_pipe['wc_2'] != null) || ($row_select_pipe['wc_3'] != "" && $row_select_pipe['wc_3'] != "0" && $row_select_pipe['wc_3'] != null)) { ?>
							
							
							<td  style="border-top:0px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;">Water Content (%)</td>
							
							<?php } if (($row_select_pipe['sp_water_abr'] != "" && $row_select_pipe['sp_water_abr'] != "0" && $row_select_pipe['sp_water_abr'] != null) || ($row_select_pipe['sp_wa_avg_2'] != "" && $row_select_pipe['sp_wa_avg_2'] != "0" && $row_select_pipe['sp_wa_avg_2'] != null) || ($row_select_pipe['sp_wa_avg_3'] != "" && $row_select_pipe['sp_wa_avg_3'] != "0" && $row_select_pipe['sp_wa_avg_3'] != null)) { ?>
							
							<td  style="border-top:0px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;">Water Absorption (%)</td>
							
							<?php } if (($row_select_pipe['por_1'] != "" && $row_select_pipe['por_1'] != "0" && $row_select_pipe['por_1'] != null) || ($row_select_pipe['por_2'] != "" && $row_select_pipe['por_2'] != "0" && $row_select_pipe['por_2'] != null) || ($row_select_pipe['por_3'] != "" && $row_select_pipe['por_3'] != "0" && $row_select_pipe['por_3'] != null)) { ?>
							
							<td  style="border-top:0px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;">Porosity (%)</td>
							
							<?php } if (($row_select_pipe['pd_1'] != "" && $row_select_pipe['pd_1'] != "0" && $row_select_pipe['pd_1'] != null) || ($row_select_pipe['pd_2'] != "" && $row_select_pipe['pd_2'] != "0" && $row_select_pipe['pd_2'] != null) || ($row_select_pipe['pd_3'] != "" && $row_select_pipe['pd_3'] != "0" && $row_select_pipe['pd_3'] != null)) { ?>
							
							<td  style="border-top:0px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;">Density(Kg/m<sup>3</sup>)</td>
							
							<?php } if (($row_select_pipe['com_99'] != "" && $row_select_pipe['com_99'] != "0" && $row_select_pipe['com_99'] != null) || ($row_select_pipe['com_100'] != "" && $row_select_pipe['com_100'] != "0" && $row_select_pipe['com_100'] != null) || ($row_select_pipe['com_101'] != "" && $row_select_pipe['com_101'] != "0" && $row_select_pipe['com_101'] != null) || ($row_select_pipe['com_102'] != "" && $row_select_pipe['com_102'] != "0" && $row_select_pipe['com_102'] != null) || ($row_select_pipe['com_103'] != "" && $row_select_pipe['com_103'] != "0" && $row_select_pipe['com_103'] != null) || ($row_select_pipe['com_104'] != "" && $row_select_pipe['com_104'] != "0" && $row_select_pipe['com_104'] != null) || ($row_select_pipe['com_105'] != "" && $row_select_pipe['com_105'] != "0" && $row_select_pipe['com_105'] != null) || ($row_select_pipe['com_106'] != "" && $row_select_pipe['com_106'] != "0" && $row_select_pipe['com_106'] != null) || ($row_select_pipe['com_107'] != "" && $row_select_pipe['com_107'] != "0" && $row_select_pipe['com_107'] != null) || ($row_select_pipe['com_108'] != "" && $row_select_pipe['com_108'] != "0" && $row_select_pipe['com_108'] != null)) { ?>
							
							<td  style="border-top:0px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;">Unconfined Compressive Strength</td>
							
							<?php } ?>
						</tr>
						
						

						<tr>
						
						 
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;"><?php echo $row_select_pipe['rock_depth']." / (".$row_select_pipe['bh_no'].")"; ?></td>
						
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;">Rock Samples</td>
							
						    <?php if (($row_select_pipe['sp_specific_gravity'] != "" && $row_select_pipe['sp_specific_gravity'] != "0" && $row_select_pipe['sp_specific_gravity'] != null) || ($row_select_pipe['sp_sg_avg_2'] != "" && $row_select_pipe['sp_sg_avg_2'] != "0" && $row_select_pipe['sp_sg_avg_2'] != null) || ($row_select_pipe['sp_sg_avg_3'] != "" && $row_select_pipe['sp_sg_avg_3'] != "0" && $row_select_pipe['sp_sg_avg_3'] != null)) { ?>
						 
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;"><?php $average = ($row_select_pipe['sp_specific_gravity'] + $row_select_pipe['sp_sg_avg_2'] + $row_select_pipe['sp_sg_avg_3']) / 3;  $average_formatted = number_format($average, 2); echo $average_formatted; ?></td>
							
							<?php } if (($row_select_pipe['wc_1'] != "" && $row_select_pipe['wc_1'] != "0" && $row_select_pipe['wc_1'] != null) || ($row_select_pipe['wc_2'] != "" && $row_select_pipe['wc_2'] != "0" && $row_select_pipe['wc_2'] != null) || ($row_select_pipe['wc_3'] != "" && $row_select_pipe['wc_3'] != "0" && $row_select_pipe['wc_3'] != null)) { ?>
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;"><?php $id1_value = $row_select_pipe['wc_1'];  $id2_value = $row_select_pipe['wc_2']; $id3_value = $row_select_pipe['wc_3'];  $total_sum = $id1_value + $id2_value + $id3_value;  $average = $total_sum / 3;  $average_formatted = number_format($average, 2); echo $average_formatted;  ?></td>
							
							<?php } if (($row_select_pipe['sp_water_abr'] != "" && $row_select_pipe['sp_water_abr'] != "0" && $row_select_pipe['sp_water_abr'] != null) || ($row_select_pipe['sp_wa_avg_2'] != "" && $row_select_pipe['sp_wa_avg_2'] != "0" && $row_select_pipe['sp_wa_avg_2'] != null) || ($row_select_pipe['sp_wa_avg_3'] != "" && $row_select_pipe['sp_wa_avg_3'] != "0" && $row_select_pipe['sp_wa_avg_3'] != null)) { ?>
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;"><?php $average = ($row_select_pipe['sp_water_abr'] + $row_select_pipe['sp_wa_avg_2'] + $row_select_pipe['sp_wa_avg_3']) / 3;  $average_formatted = number_format($average, 2); echo $average_formatted; ?></td>
							
							<?php } if (($row_select_pipe['por_1'] != "" && $row_select_pipe['por_1'] != "0" && $row_select_pipe['por_1'] != null) || ($row_select_pipe['por_2'] != "" && $row_select_pipe['por_2'] != "0" && $row_select_pipe['por_2'] != null) || ($row_select_pipe['por_3'] != "" && $row_select_pipe['por_3'] != "0" && $row_select_pipe['por_3'] != null)) { ?>
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;"><?php $average = ($row_select_pipe['por_1'] + $row_select_pipe['por_2'] + $row_select_pipe['por_3']) / 3;  $average_formatted = number_format($average, 2); echo $average_formatted; ?></td>
							
							<?php } if (($row_select_pipe['pd_1'] != "" && $row_select_pipe['pd_1'] != "0" && $row_select_pipe['pd_1'] != null) || ($row_select_pipe['pd_2'] != "" && $row_select_pipe['pd_2'] != "0" && $row_select_pipe['pd_2'] != null) || ($row_select_pipe['pd_3'] != "" && $row_select_pipe['pd_3'] != "0" && $row_select_pipe['pd_3'] != null)) { ?>
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;"><?php $average = ($row_select_pipe['pd_1'] + $row_select_pipe['pd_2'] + $row_select_pipe['pd_3']) / 3; $average_formatted = number_format($average, 2); echo $average_formatted; ?></td>
							
							<?php } if (($row_select_pipe['com_99'] != "" && $row_select_pipe['com_99'] != "0" && $row_select_pipe['com_99'] != null) || ($row_select_pipe['com_100'] != "" && $row_select_pipe['com_100'] != "0" && $row_select_pipe['com_100'] != null) || ($row_select_pipe['com_101'] != "" && $row_select_pipe['com_101'] != "0" && $row_select_pipe['com_101'] != null) || ($row_select_pipe['com_102'] != "" && $row_select_pipe['com_102'] != "0" && $row_select_pipe['com_102'] != null) || ($row_select_pipe['com_103'] != "" && $row_select_pipe['com_103'] != "0" && $row_select_pipe['com_103'] != null) || ($row_select_pipe['com_104'] != "" && $row_select_pipe['com_104'] != "0" && $row_select_pipe['com_104'] != null) || ($row_select_pipe['com_105'] != "" && $row_select_pipe['com_105'] != "0" && $row_select_pipe['com_105'] != null) || ($row_select_pipe['com_106'] != "" && $row_select_pipe['com_106'] != "0" && $row_select_pipe['com_106'] != null) || ($row_select_pipe['com_107'] != "" && $row_select_pipe['com_107'] != "0" && $row_select_pipe['com_107'] != null) || ($row_select_pipe['com_108'] != "" && $row_select_pipe['com_108'] != "0" && $row_select_pipe['com_108'] != null)) { ?>
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;font-weight:bold;padding:10px 4px;"><?php $average = ($row_select_pipe['com_99'] + $row_select_pipe['com_100'] + $row_select_pipe['com_101'] + $row_select_pipe['com_102'] + $row_select_pipe['com_103'] + $row_select_pipe['com_104'] + $row_select_pipe['com_105'] + $row_select_pipe['com_106'] + $row_select_pipe['com_107'] + $row_select_pipe['com_108']) / 10; $average_formatted = number_format($average, 2); echo $average_formatted; ?></td>
							
							<?php } ?>
						</tr>
		      
						<tr>
							<td colspan="2" style="border-top:1px solid;border-left: 1px solid black;text-align:center;padding:10px 4px;"> Test Method Specification</td>
							
							 <?php if (($row_select_pipe['sp_specific_gravity'] != "" && $row_select_pipe['sp_specific_gravity'] != "0" && $row_select_pipe['sp_specific_gravity'] != null) || ($row_select_pipe['sp_sg_avg_2'] != "" && $row_select_pipe['sp_sg_avg_2'] != "0" && $row_select_pipe['sp_sg_avg_2'] != null) || ($row_select_pipe['sp_sg_avg_3'] != "" && $row_select_pipe['sp_sg_avg_3'] != "0" && $row_select_pipe['sp_sg_avg_3'] != null)) { ?>
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;padding:10px 4px;">IS 1124</td>
							
							<?php } if (($row_select_pipe['wc_1'] != "" && $row_select_pipe['wc_1'] != "0" && $row_select_pipe['wc_1'] != null) || ($row_select_pipe['wc_2'] != "" && $row_select_pipe['wc_2'] != "0" && $row_select_pipe['wc_2'] != null) || ($row_select_pipe['wc_3'] != "" && $row_select_pipe['wc_3'] != "0" && $row_select_pipe['wc_3'] != null)) { ?>
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;padding:10px 4px;">IS 13030</td>
							
							<?php } if (($row_select_pipe['sp_water_abr'] != "" && $row_select_pipe['sp_water_abr'] != "0" && $row_select_pipe['sp_water_abr'] != null) || ($row_select_pipe['sp_wa_avg_2'] != "" && $row_select_pipe['sp_wa_avg_2'] != "0" && $row_select_pipe['sp_wa_avg_2'] != null) || ($row_select_pipe['sp_wa_avg_3'] != "" && $row_select_pipe['sp_wa_avg_3'] != "0" && $row_select_pipe['sp_wa_avg_3'] != null)) { ?>
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;padding:10px 4px;">IS 1124</td>
							
							<?php } if (($row_select_pipe['por_1'] != "" && $row_select_pipe['por_1'] != "0" && $row_select_pipe['por_1'] != null) || ($row_select_pipe['por_2'] != "" && $row_select_pipe['por_2'] != "0" && $row_select_pipe['por_2'] != null) || ($row_select_pipe['por_3'] != "" && $row_select_pipe['por_3'] != "0" && $row_select_pipe['por_3'] != null)) { ?>
							
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;padding:10px 4px;">IS 13030</td>
							
							<?php } if (($row_select_pipe['pd_1'] != "" && $row_select_pipe['pd_1'] != "0" && $row_select_pipe['pd_1'] != null) || ($row_select_pipe['pd_2'] != "" && $row_select_pipe['pd_2'] != "0" && $row_select_pipe['pd_2'] != null) || ($row_select_pipe['pd_3'] != "" && $row_select_pipe['pd_3'] != "0" && $row_select_pipe['pd_3'] != null)) { ?>
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;padding:10px 4px;">IS 13030</td>
							
							<?php } if (($row_select_pipe['com_99'] != "" && $row_select_pipe['com_99'] != "0" && $row_select_pipe['com_99'] != null) || ($row_select_pipe['com_100'] != "" && $row_select_pipe['com_100'] != "0" && $row_select_pipe['com_100'] != null) || ($row_select_pipe['com_101'] != "" && $row_select_pipe['com_101'] != "0" && $row_select_pipe['com_101'] != null) || ($row_select_pipe['com_102'] != "" && $row_select_pipe['com_102'] != "0" && $row_select_pipe['com_102'] != null) || ($row_select_pipe['com_103'] != "" && $row_select_pipe['com_103'] != "0" && $row_select_pipe['com_103'] != null) || ($row_select_pipe['com_104'] != "" && $row_select_pipe['com_104'] != "0" && $row_select_pipe['com_104'] != null) || ($row_select_pipe['com_105'] != "" && $row_select_pipe['com_105'] != "0" && $row_select_pipe['com_105'] != null) || ($row_select_pipe['com_106'] != "" && $row_select_pipe['com_106'] != "0" && $row_select_pipe['com_106'] != null) || ($row_select_pipe['com_107'] != "" && $row_select_pipe['com_107'] != "0" && $row_select_pipe['com_107'] != null) || ($row_select_pipe['com_108'] != "" && $row_select_pipe['com_108'] != "0" && $row_select_pipe['com_108'] != null)) { ?>
							
							<td  style="border-top:1px solid;border-left: 1px solid black;text-align:center;padding:10px 4px;">IS 9143</td>
							
							<?php } ?>
						</tr>
						
						
							
					</table>
				</td>
			</tr>
			
		</table>
		


		<!-- footer design ->
		<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;border: 1px solid;border-top: 0;">
			
			<tr>
				<td>
					<table align="center" width="100%" cellspacing="0" cellpadding="0" style="font-size:11px;font-family : Calibri;border: 1px solid;border-top: 0;">
						<tr>
							<td style="padding: 10px 0;border-bottom: 1px solid;"></td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;text-transform: uppercase;font-weight: bold;">Report Issue By:- GEO RESEARCH HOUSE, INDORE.</td>
						</tr>
						<tr>
							<td style="padding: 1px 0 0;border-bottom: 1px solid;"></td>
						</tr>
						<tr style="vertical-align: bottom;">
							<td style="padding: 1px 2px;height: 45px;">{Mr. Chitrath Purani}</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;">Report Reviewed & Authorized by :-</td>
						</tr>
						<tr>
							<td style="padding: 1px 0 0;border-bottom: 1px solid;"></td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;">NOTES :-</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;">1. The Samples have been Submitted to us by the Customer.</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;">2. The above given Results Refer only to the sample submitted by the customer for testing.</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;">3. All the information is Provided to us by the Customer and can affect the Result Validity.</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;">4. This Report shall not be Reproduced without Approval of the Laboratory.</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;">5. * As Informed by Client.</td>
						</tr>
						<tr>
							<td style="padding: 1px 40px;font-weight: bold;text-align: right;">Doc. ID :- FMT/TST - 012 / Page no:- 1 of 1</td>
						</tr>
						<tr>
							<td style="padding: 1px 2px;font-weight: bold;text-align: center;">****** End of Report ******</td>
						</tr>
					</table>
				</td>
			</tr>

		</table>-->


    </page>
<?php //} ?>


		<?php
			
			if($flag==8)
				{
					$flag=0;
					$down=$up;
					$up +=8;
					?>
					
		
		
					<div class="pagebreak"> </div>
			<?php }
			
			
			}
			
		?>
		
	</body>
</html>
<script src="jquery.min.js"></script>		
<script type="text/javascript">
	function header(){
		if(document.querySelector('#header_hide_show').checked){
			document.getElementById('header').innerHTML = '';
			document.getElementById("header").insertAdjacentHTML("afterbegin", '<img src="../images/header.png" width="100%">');
			document.getElementById("footer").insertAdjacentHTML("afterbegin", '<img src="../images/stamp_tag.png" width="160px">');
			document.getElementById('sign').innerHTML = '';
			document.getElementById("sign").insertAdjacentHTML("afterbegin", '<img src="../images/sign.png" width="160px">');
		} else{
			document.getElementById('header').innerHTML = '';
			document.getElementById("header").insertAdjacentHTML("afterbegin", '<br><br><br><br><br><br><br><br><br>');
			document.getElementById("footer").innerHTML = '';
			document.getElementById('sign').innerHTML = '';
			document.getElementById("sign").insertAdjacentHTML("afterbegin", '<img src="../images/stamp.png" width="160px">');
		}
	}
	
	function loading(){
		
			document.getElementById('header').innerHTML = '';
			document.getElementById("header").insertAdjacentHTML("afterbegin", '<br><br><br><br><br><br><br><br><br>');
			document.getElementById("footer").innerHTML = '';
			document.getElementById('sign').innerHTML = '';
			document.getElementById("sign").insertAdjacentHTML("afterbegin", '<img src="../images/stamp.png" width="160px">');
		
	}

</script>